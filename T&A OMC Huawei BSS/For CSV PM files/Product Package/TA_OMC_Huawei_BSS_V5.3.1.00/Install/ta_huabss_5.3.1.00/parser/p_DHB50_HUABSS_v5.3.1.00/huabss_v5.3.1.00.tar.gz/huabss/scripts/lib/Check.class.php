<?php

/**
 * 
 * Cette classe sert � d�finir les m�thodes de v�rification g�n�riques : l'i�de est de disposer 
 * d'un script ind�pendant de T&A, capable de v�rifier que des fichiers sources sont
 * conforme au format attendu (ex : contr�le du format du nom du fichier, du format de date, etc).
 * 
 */
class Check {
	
	public function __construct() {
		
	}
}

?>