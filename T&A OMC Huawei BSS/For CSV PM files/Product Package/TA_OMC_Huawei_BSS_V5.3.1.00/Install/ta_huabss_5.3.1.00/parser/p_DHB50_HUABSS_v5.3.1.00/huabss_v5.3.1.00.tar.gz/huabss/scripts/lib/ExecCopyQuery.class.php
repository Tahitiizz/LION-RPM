<?php

/**
 * 
 * Classe charg�e, via une requ�te COPY, de charger le contenu de fichiers temporaires (.sql)
 * dans des tables temporaires de la BDD. 
 *
 */

class ExecCopyQuery {
	/**
	 * 
	 * Propri�t�s des familles
	 * @var ParametersList
	 */
	public $params;
	
	/**
	 * 
	 * Fichiers temporaires � traiter
	 */
	public $tempFilesCondition;

	
	/**
	*
	* Objet de gestion de la connexion � la base de donn�es
	* @var DataBaseConnection
	*/
	protected $dbConnection;
	
	/**
	*
	* Permet l'acc�s aux fonctions de requ�te vers la base de donn�es
	* @var DatabaseServices
	*/
	public $dbServices;
	
	/**
	 * Constructeur.
	 */
	public function __construct(TempFilesCondition $tempFilesCondition)
	{
		// fichiers temporaires � traiter
		$this->tempFilesCondition=$tempFilesCondition;
		
		//r�cup�ration des propri�t�s des familles
		$this->readSerializedParam();
		
		$this->dbConnection=new DatabaseConnection();
		
		//objet DataBaseServices specifique ou g�n�rique selon getDatabaseServicesClassName()
		$this->dbServices = $this->getDatabaseServicesObject();
		
	}

	/**
	*
	* M�thode statique qui retourne la liste des entit�s utiles 
	* (= celles pour lesquelles des compteurs sont activ�s, Cf. \lib\Parser.class.php->initiateParam()).
	* Cela correspond aux fichiers temporaires en attente de copie vers les tables w_astellia.
	* @param ParametersList $paramsList objet avec les param�tres des familles
	* @param array $hours tableau des heures collect�es
	* @return array $tabTempFiles
	*/
	public static function getConditions(ParametersList $paramsList,$hours=null) {
		// initialisation du r�sultat		
		$conditionsTab=array();
		
		// tableau temporaire listant les entit�s
		$tabTempFiles=array();
		
		// pour chaque famille
		foreach($paramsList AS $param) {
			// pour chaque entit� de la famille courante
			foreach($param->todo as $entity=>$counters){
				//TODO MHT2 checker si au moins un fichier temporaire existe pour une des heures collect�es, le niveau et le todo	
				if(Tools::tempFileExistsForEntity($param->network[0],$entity,$hours)){
					//si aucun fichier n'est trouv� pour au moins une des heures collect�es, ne pas ajouter l'entit�
					$tabTempFiles[]=$entity;
				}
			}
		}
		
		// d�doublonnage pour le cas o� un m�me nom d'entit� est utilis� dans plusieurs familles 
		//TODO MHT2 n'est pas possible car l'entit� est compos�e de la famille -> inutile
		//$tabTempFiles=array_unique($tabTempFiles);
		
		// pour chaque entit�, on cr�e un objet condition
		foreach($tabTempFiles as $entity){
			// TODO : � tester si le fichier temporaire existe :
			//   - son nom est obtenu avec  Tools::getCopyFilePath($level, $cle_entite,$hour);
			//   - le test d'existence du fichier est fait tardivement dans DatabaseServices->clean_copy_files
			//   - cela �viterait de cr�er des processus inutiles (10% des process sur Ericsson BSS)
			//   - cela �viterait les cr�ations de tables temporaires, les messages � Le fichier pour le COPY n'est pas present �, etc
			
			// condition d��ligibilit� des fichiers temporaires
			$condition=new TempFilesCondition($entity,$hours);
			$conditionsTab[]=$condition;
		}
		unset($tabTempFiles);
		
		// log dans le file_demon
		displayIndemon("ExecCopyQuery : ".count($conditionsTab)." conditions ont �t� cr��es suite � une d�clinaison par entit�.");
		
		return $conditionsTab;
	}
	
	/**
	*
	* Initialise des propri�t�s d'objet ParameterList
	* @param array $family2Param Tableau associatif pour les param�tres field, specific_field, group_table et network
	*
	*/
	protected function readSerializedParam() {
	
		$filename=REP_PHYSIQUE_NIVEAU_0 . "parser/paramsSerialized.ser";
		// Si le fichier existe et on l'utilise (gain en perf!).
		if(file_exists($filename)){
			$paramsSerialized="";
			$handle=fopen($filename,'rt');
			if ($handle) {
			//verrou en lecture partag�e (bloque jusqu'� lib�ration du verrou exlusif s'il existe)
				flock($handle, LOCK_SH);
			while (!feof($handle)) {
			$paramsSerialized .= fgets($handle);
			}
			flock($handle, LOCK_UN);//d�v�rouillage
			fclose($handle);
			}else{
			$message="Error: Unable to open parameter file ($filename)";
						sys_log_ast("Critical", "Trending&Aggregation", __T("A_TRACELOG_MODULE_LABEL_COLLECT"), $message, "support_1", "");
						displayInDemon($message,'alert');
					}			
			$this->params=unserialize($paramsSerialized);
			if(($this->params==false)||($this->params=='')){
			$message="Error: Unable to unserialize parameter file ($filename)";
						sys_log_ast("Critical", "Trending&Aggregation", __T("A_TRACELOG_MODULE_LABEL_COLLECT"), $message, "support_1", "");
						displayInDemon($message,'alert');
					}
		}
		//sinon le fichier n'existe pas
		else{
			$message="Error: file $filename not found";
			sys_log_ast("Critical", "Trending&Aggregation", __T("A_TRACELOG_MODULE_LABEL_COLLECT"), $message, "support_1", "");
			displayInDemon($message,'alert');
		}
	}
	
	
	/**
	*
	* Retourne un objet DatabaseServices, �ventuellement � partir d'une classe
	* fille d�finie c�t� sp�cifique (Cf. getDatabaseServicesClassName ci-apr�s)
	*/
	private function getDatabaseServicesObject(){
		$databaseServicesClassName=$this->getDatabaseServicesClassName();
		try {
			$dbServicesClass = new ReflectionClass($databaseServicesClassName);
			$databaseServicesObject = $dbServicesClass->newInstance($this->dbConnection);
			return $databaseServicesObject;
		} catch (ReflectionException $ex) {
			displayInDemon("Erreur au lancement du traitement ExecCopyQuery : " . $ex->getMessage());
			return NULL;
		}
	}
	
	
	/**
	 *
	 * C�t� sp�cifique : � red�nir si besoin.
	 */
	protected function getDatabaseServicesClassName(){
		return "DatabaseServices";
	}
	
}

?>