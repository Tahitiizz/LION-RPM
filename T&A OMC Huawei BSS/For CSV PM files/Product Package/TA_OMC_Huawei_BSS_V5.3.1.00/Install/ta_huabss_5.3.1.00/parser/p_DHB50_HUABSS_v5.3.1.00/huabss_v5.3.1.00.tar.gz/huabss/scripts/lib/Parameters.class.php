<?php

class Parameters {
	
	/**
	 * Tableau des niveaux de topologie
	 * @var array
	 */
	public $topoHeader;
	public $family;
	public $field;
	public $specific_field;
	public $id_group_table;
	public $network;
	public $topoCellsArray;
	public $todo;
	//liste des �l�ments r�seaux (de base) d�sactiv�s pour cette famille
	public $deactivated_NE;//false or an array
	
	public function __construct() {
		$this->topoCellsArray = array();
		$this->deactivated_NE = false;
	}

	/**
	 * 
	 * Enter description here ...
	 * @param $ne_base_level identifiant du niveau r�seau de base de la famille (Expl cellId pour BSS)
	 * @param $topoInfo tableau associatif des �l�ments de topo en conformit� avec TopoHeader
	 * @param $hour heure du fichier en cours de traitement
	 * @param $ne_id_case casse des �l�ments r�seaux: upperCase (default), lowerCase, rawCase
	 */
	public function addTopologyInfo($ne_base_level_id, $topoInfo,$hour,$ne_id_case="upperCase"){
		//$ne_base_level_id insensible � la casse
		foreach ($topoInfo as $key => $ne_id) {
			if($ne_id_case=="lowerCase"){
				$ne_id=strtolower($ne_id);
			}elseif($ne_id_case=="rawCase"){
				//no change
			}else{
				$ne_id=strtoupper($ne_id);
			}
			//virtual_ en minuscule
			if(preg_match("/virtual_(.*)/i", $ne_id,$matches)){
				$ne_id="virtual_{$matches[1]}";
			}
			$topoInfo_new[$key]=$ne_id;
		}
		$this->topoCellsArray[$hour][strtolower($ne_base_level_id)] = $topoInfo_new;
	}
}

/**
 * Enter description here ...
 * @author g.francois
 *
 */
class ParametersList implements Iterator {
/**
	 * 
	 * Index de la liste
	 * @var int
	 */
	private $index;
	/**
	 * 
	 * Liste contenant les objets Parameters
	 * @var array
	 */
	private $list;
	
	/**
	 * 
	 * Constructeur
	 */
	public function __construct() {
		$this->list = array();
		$this->index = 0;
	}
	
	/**
	 * 
	 * Ajoute un objet Parameters � la liste
	 * @param Parameters $param
	 */
	public function add(Parameters $param) {
		$this->list[] = $param;
	}

	/**
	 * 
	 * R�cup�re l'objet Parameters
	 * @param String $family
	 * @return Parameters
	 */
	public function getWithFamily($family) {
		foreach ($this as $param) {
			if ($param->family == $family) {
				return $param;
			}
		}
		return null;
	}
	
	/**
	 * 
	 * R�cup�re le ou les objets Counter � partir du compteur trouv� dans le fichier source
	 * Initialise la valeur qui d�finit le compteur dans le fichier source sous sa propri�t� nms_field_name_in_file
	 * @param String $nms_field_name
	 * @return array Tableau compos� de la liste des compteurs (objet) correspondant � ce $nms_field_name
	 */
	public function getCounterFromFile($nms_field_name, $id_group_table=null) {
		//liste des compteurs trouv�s sachant que plusieur compteurs peuvent avoir un meme $nms_field_name
		$countersFound= array();
		$found=false;
		
	
			foreach ($this as $param) {
				if(isset($id_group_table)){
					if($param->id_group_table!=$id_group_table) continue;
				}
				
				foreach ($param->todo as $counters) {
					foreach ($counters as $pos => $counter) {
                        $nms_field_name_array = array_map("strtolower", $counter->nms_field_name);
                        if (in_array(strtolower($nms_field_name), $nms_field_name_array))  {
                            $counter->nms_field_name_in_file = $nms_field_name;
                            $countersFound[]=$counter;
                            $found=true;
                            //return array($pos, $counter);
                        }
                        else{
                            /*cas des compteurs d�clin�s o� nms_field_name contient des "@@".
                             * exemple : nms_field_name = NUMDEST_ANSWERED_CALLS@@DEST_DIR_ID=1&&DEST_TYPE_ID=10
                             * le nms_field_name pass� en param�tre est NUMDEST_ANSWERED_CALLS. 
                             * on d�coupe donc $counter->nms_field_name suivant "@@" pour comparer"
                             */
                            foreach($nms_field_name_array as $nms_field_name_att){
                                if(strpos($nms_field_name_att,"@@")){
                                    $nms_field_name_exp = explode("@@",$nms_field_name_att);
                                    if (strtolower($nms_field_name)==$nms_field_name_exp[0]){
                                        $counter->nms_field_name_in_file = $nms_field_name;
                                        $countersFound[]=$counter;
                                        $found=true;
                                    }
                                }
                            }
                        }
                    }
                }
            }

        if($found==false)
            return null;
        else
            return $countersFound;
    }
    /**
     * 
     * Enter description here ...
     * @param unknown_type $nms_field_name
     * @param unknown_type $todo
     */
	public function getCountersByNmsTable($nms_table) {
		$countersFoundPerTodo=array();
		foreach ($this as $param) {
			foreach (array_keys($param->todo) as $todo) {
				if(preg_match("/_{$nms_table}$/i", $todo)){
					if(count($param->todo[$todo])!=0){
						$countersFoundPerTodo[$todo]=$param->todo[$todo];
					}
				}
			}
		}
		return $countersFoundPerTodo;
    }
    

    /**
     * 
     * Renvoie l'objet Parameters contenant le $todo dans sa liste des $todo
     * @param String $todo
     */
    public function getParamWithTodo($todo) {
        foreach ($this as $param) {
            if (in_array(strtolower($todo), array_map("strtolower", array_keys($param->todo)))) {
                return $param;
            }
        }
        return null;
    }

    /**
     * 
     * R�cup�re l'objet Parameters
     * @param String $id_group_table
     * @return Parameters
     */
    // TODO : dans la m�thode "add", utiliser le $id_group_table comme cl�
    public function getWithGroupTable($id_group_table) {
        foreach ($this as $param) {
            if ($param->id_group_table == $id_group_table) {
                return $param;
            }
        }
        return null;
    }

    /**
     * (non-PHPdoc)
     * @see Iterator::rewind()
     */
    public function rewind() {
        $this->index = 0;
    }

    /**
     * (non-PHPdoc)
     * @see Iterator::next()
     */
    public function next() {
        $this->index++;
    }

    /**
     * (non-PHPdoc)
     * @see Iterator::key()
     */
    public function key() {
        return $this->list[$this->index]->family;
    }

    /**
     * (non-PHPdoc)
     * @see Iterator::current()
     */
    public function current() {
        return $this->list[$this->index];
    }

    /**
     * (non-PHPdoc)
     * @see Iterator::valid()
     */
    public function valid() {
        return $this->index<count($this->list);
    }
}
?>