Module Alarm
-------------------------------------------------------------------------------------------------------------------------------------------------

alarm_v6.0.0
- passage de mysql � oracle


alarm_v1.0.4
- correction du bug 7754 : mauvais titre de fen�tre de cr�ation d'une nouvelle alarme
- correction du bug 7751 : mauvaise d�finition du protocole employ� (erreur avec "https")

alarm_v1.0.3
- renommage de la table 'alk_service' en 'alk_services' dans "class/AlarmModel.class.php" (demande SLM)

alarm_v1.0.2
- suppression des fichiers de configuration "php/app_conf.php" et "php/app_conf_ta.php" (non utilis� par SLM)
- suppression du fichier d'exemple � la racine (non utilis� par SLM)
- modification du chemin vers le fichier de configuration dans "./index.php" pour se r�f�rer � celui de SLM

alarm_v1.0.1
- masquage du bouton de suppression du trigger
- suppression du message "(Triggers are linked using an \'AND\' condition)"

alarm_v1.0.0
version de base