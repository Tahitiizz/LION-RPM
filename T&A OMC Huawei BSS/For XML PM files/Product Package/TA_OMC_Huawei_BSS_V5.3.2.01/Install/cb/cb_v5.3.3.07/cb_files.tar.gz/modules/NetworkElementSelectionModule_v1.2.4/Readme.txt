Changements pour la version 1.2.4 :	-- BBX le 25/11/2008
	- "networkElementSelection.class.php" : ajout d'un div qui contient el champs de saisie 
afin de pouvoir d�truire puis reconstruire son contenu
	- "networkElementSelection.js" : destruction puis reconstruction du champ de recherche
pour que l'autocompl�tion fonctionne correctement
	- Mise � jour de "controls.js" et "scriptaculous.js" en version 1.8.1
	- Gestion de la recherche absolue : si une liste est trop longue et tronqu�e mais que l'�l�ment est choisit par la recherche,
on ajoute cet �l�ment � la liste
	
Changements pour la version 1.2.3 :	-- BBX le 09/10/2008

	- modification de la recherche : suppression des lignes concernant la recherche dans le fichier js et utilisation des m�thodes fournies 
par script aculous.
	- modification de la recherche c�t� php (get_search.php)
	- ajout de la librairie js "controls.js" fournie par script aculous et n�cessaire � l'auto-compl�tion.


Changements pour la version 1.2.2 :	-- SLC le 23/09/2008

	- ajout de networkElementSelectionSaveHook() permettant de redonner la main � la page qui contient le module apr�s sauvegarde


Changements pour la version 1.2.1 :

- mise en conformit� avec les normes W3C du fichier networkElementSelection.css (suite au mail de mickael Lebreton).
- quand on est en mode bouton radio et que on clique sur le bouton 'View current selection' si on a param�tr� un fichier 
php � l'appel de la m�thode setViewCurrentSelectionContentButtonProperties(), on peut personnaliser l'affichage. En variables
_GET de ce fichier sont ajout�s la valeur de chaque onglet. Ainsi on peut savoir quelle valeur appartient � quel onglet.