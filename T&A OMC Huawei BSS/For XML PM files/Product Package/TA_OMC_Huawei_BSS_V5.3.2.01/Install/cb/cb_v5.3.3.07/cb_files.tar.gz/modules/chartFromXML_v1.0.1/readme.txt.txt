/_documentation/
Repertoire contenant la documentation.


/class/
La classe chartFromXML.php et la surclasse de SimpleXML.


/jpgraph-2.3.3/
Les fichiers modifi�s de JpGraph.

/jpgraph_delta/
Les 5 fichiers modifi�s par rapport � la version originale 2.3.3 de jpgraph.

/exemples/
Exemples et tests de l'utilisation de chartFromXML.php



