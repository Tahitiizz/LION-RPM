/**
*	JavaScript allant avec les boites filter du s�lecteur
*
*	@author	BBX - 26/11/2008
*	@version	CB 4.1.0.0
*	@since	CB 4.1.0.0
*
*/


/*****************************************************
* 	Fonction toggleSelecteur
* 	Affiche / masque le s�lecteur avec effet de slide
* 	@author : BBX
*	@version	CB 4.1.0.0
*	@since	CB 4.1.0.0
* 	@return void
*****************************************************/
function toggleSelecteur()
{
	// D�composition du chemin de l'image contenu dans le bouton
	var tabPath = $('selecteur_img_toogle').src.split('/');
	var imageName = tabPath[tabPath.length-1];
	// D�composition du chemin de l'image img1
	var tabPath = _selecteurFilterImageHide.split('/');
	var img1Name = tabPath[tabPath.length-1];
	// D�composition du chemin de l'image img2
	var tabPath = _selecteurFilterImageShow.split('/');
	var img2Name = tabPath[tabPath.length-1];
	// Test
	if(imageName == img1Name) {
		$('selecteur_img_toogle').src = _selecteurFilterImageShow;
		$('selecteur_status').value = "none";
	}
	else {
		$('selecteur_img_toogle').src = _selecteurFilterImageHide;
		$('selecteur_status').value = "block";
	}
	Effect.toggle('selecteur_container', 'slide');
}

/*****************************************************
* 	Fonction toggleSelecteurPopup
* 	Affiche la tooltip du bouton selon l'�tat (show/hide)
* 	@author : BBX
*	@version	CB 4.1.0.0
*	@since	CB 4.1.0.0
* 	@return void
*****************************************************/
function toggleSelecteurPopup()
{
	// D�composition du chemin de l'image contenu dans le bouton
	var tabPath = $('selecteur_img_toogle').src.split('/');
	var imageName = tabPath[tabPath.length-1];
	// D�composition du chemin de l'image img1
	var tabPath = _selecteurFilterImageHide.split('/');
	var img1Name = tabPath[tabPath.length-1];
	// D�composition du chemin de l'image img2
	var tabPath = _selecteurFilterImageShow.split('/');
	var img2Name = tabPath[tabPath.length-1];
	// Test
	if(imageName == img1Name) {
		popalt(_selecteurFilterTextHide);
	}
	else {
		popalt(_selecteurFilterTextShow);
	}
}

/*****************************************************
* 	Lancement de l'observateur d'�v�nement sur les touches press�es
*	Si on presse F2, on affiche / cache le s�lecteur
*****************************************************/
document.observe("dom:loaded", function() {
	Event.observe(document, 'keyup', function(event) 
	{
		var key = event.which || event.keyCode;
		if(key == 113) {
			toggleSelecteur();
		}
	});
});

/*****************************************************
* 	Lancement de l'observateur sur le statut du s�lecteur
*	Si on a cach� le s�lecteur, on le recache lors de l'autorefresh
*****************************************************/
document.observe("dom:loaded", function() {
	if($('selecteur_status')) {
		if($('selecteur_status').value != '') {			
			if($('selecteur_status').value == 'block') $('selecteur_img_toogle').src = _selecteurFilterImageHide;
			else $('selecteur_img_toogle').src = _selecteurFilterImageShow;
			$('selecteur_container').style.display = $('selecteur_status').value;
		}
	}
});



