/**
 * D�finition des fonctions de gestion de l'index des dashboards
 *
 *	04/06/2009 GHX
 *		- Suppression de la fonction createIndex()
 *		- Modification de la fonction slideIndexContent() afin de pouvoir replier les listes
 *
 *	11/05/2010 OJT
 *	    - Ajout de la fonction showDataTable pour les tables de donn�es
 */

/**
 * Permet d'afficher / masquer les �l�ments des GTMs
 * 
 * 11/03/09 - modif SPS : - changement des effets lors de l'affichage/masquage (slideup/slidedown -> show/hide)
 *						  - on cache toutes les listes � chaque appel, pour ensuite n'afficher que celle que l'on souhaite
 * 						  - suppression de la propriete height=auto
 *
 *	15:11 04/06/2009 GHX
 *		- Correction de la fonction pour que quand la liste est d�pli�e on puisse la repli�e
 *
 * @param string id_toslide identifiant du div � afficher / masquer contenant les �l�ments du GTM
 * @param string id_btn_slide identifiant du bouton appelant
 */

function slideIndexContent(id_toslide, id_btn_slide)
{	

	if ($('index_dashboard_content')) {
		var tIndexElementsList = new Array();
		var tIndexButton = new Array();
		
		//On recupere la liste des input de type button
		tIndexButton = $('index_dashboard_content').select('input[type="button"]');
		
		//On change le nom de la classe de chacun des input
		for (var i=0;i < tIndexButton.length;i++)
		{
			// 15:12 04/06/2009 GHX
			// Ajout de la condition
			if ( tIndexButton[i].id != id_btn_slide )
			{
				tIndexButton[i].removeClassName('IndexGTMButtonDown');
				tIndexButton[i].addClassName('IndexGTMButtonUp');
			}
		}
		
		//On recupere la liste des elements de classe IndexElementsList
		tIndexElementsList = $('index_dashboard_content').getElementsByClassName('IndexElementsList');
		
		//On cache tous les elements trouves	
		for (var j=0;j < tIndexElementsList.length;j++)
		{
			tIndexElementsList[j].hide();
		}
		
		// Affichage du div
		if ( $(id_btn_slide).hasClassName('IndexGTMButtonUp') )
		{
			$(id_btn_slide).addClassName('IndexGTMButtonDown');
			$(id_btn_slide).removeClassName('IndexGTMButtonUp');
			$(id_toslide).show();
		}
		else // Masquage du div
		{
			$(id_btn_slide).addClassName('IndexGTMButtonUp');
			$(id_btn_slide).removeClassName('IndexGTMButtonDown');
			$(id_toslide).hide();
		}
	}
}

/**
 * Permet d'afficher / masquer le div contenant les GTMs pr�sents dans le dashboard
 * 11/03/09 - modif SPS : - changement des effets lors de l'affichage/masquage (slideup/slidedown -> show/hide)
 * 						  - suppression de la propriete height=auto
 */
function slideIndexBox()
{	
	if ($('index_dashboard_content')) {
		// Affichage du div de contenu de l'index
	
		if ($('index_dashboard_content').style.display == "none")
		{
			//new Effect.SlideDown($('index_dashboard_content'), {scaleX: true});
			$('index_dashboard_content').style.display = "block";
		}
		else // Masquage du div de contenu de l'index
		{
			//new Effect.SlideUp($('index_dashboard_content'), {scaleX: true});
			$('index_dashboard_content').style.display = "none";
		}
	}
}

/**
 * Gestion de l'affichage d'une table de donn�es sous un Dashboard
 * @param xmlFilePath Chemin/Nom/Extension du fichier XML source
 * @param xmlName Nom du fichier sans le chemin nin l'extension
 */
function showDataTable( xmlFilePath, xmlName )
{
    /** @var string Pr�fixe du conteneur de la table de donn�es */
    var pre = "gtm_dt_";

    // Test si le conteneur est accessible via son identifiant
    if( $( pre + xmlName ) != null )
    {
        // Test si la table de donn�es est d�ja affich�e
        if( $( pre + xmlName ).getStyle( "display" ) == "none"  )
        {
            // La table n'est pas affich�e, on test si elle contient d�ja des donn�es
            if( $( pre + xmlName ).innerHTML.length == 0 )
            {
                $( pre + xmlName + "_open" ).hide();
                $( pre + xmlName + "_wait" ).show();

                // Appel A.J.A.X. pour la g�nar�tion de la table de donn�es
                new Ajax.Request( "gtmDataTableGeneration.php",
                    {
                        method:"post",
                        parameters:"filename=" + xmlFilePath,
                        onSuccess: function( res )
                        {
                            $( pre + xmlName ).insert( res.responseText );
                            $( pre + xmlName ).setStyle( {"height":Math.min( parseInt( $( pre + xmlName ).getHeight() + 55 ), 450 ) + "px"} );
                            showDataTableContainer( 0, pre + xmlName );
                            $( pre + xmlName + "_open" ).hide();
                            $( pre + xmlName + "_wait" ).hide();
                            $( pre + xmlName + "_close" ).show();                            
                        }
                    });
            }
            else
            {
                // Les donn�es ont d�j� �t� g�n�r�es... On r�affiche simplement
                $( pre + xmlName + "_open" ).hide();
                showDataTableContainer( 0, pre + xmlName );
                $( pre + xmlName + "_close" ).show();
            }
        }
        else
        {
            // La table est affich�e... On la ferme
            $( pre + xmlName + "_close" ).hide();
            showDataTableContainer( 1, pre + xmlName );
            $( pre + xmlName + "_open" ).show();
        }
    }
    else
    {
        // L'�l�ment est introuvable
        alert( "Data could not be retrieve, please refresh the page" );
    }
}

/**
 * Gestion de l'effet graphique de la table de donn�es avec v�rification de la
 * pr�sence des m�thode de la librairie Scriptaculous
 * @param mode Mode de l'effet (0 pour l'ouverture, 1 pour la fermeture)
 * @param id Identifiant du conteneur � afficher ou cacher
 */
function showDataTableContainer( mode, id )
{
    /** @var Float Dur�e de l'effet graphique (0.5 recommand�) */
    var effectDuration = 0.5;

    // V�rification de la pr�sence des m�thode Scriptaculous
    if( ( typeof Effect == "object" ) && ( typeof Effect.BlindDown == "function" ) )
    {
        if( mode == 0 )
        {
            Effect.BlindDown( $( id ), {duration:effectDuration} );
        }
        else
        {
            Effect.BlindUp( $( id ), {duration:effectDuration} );
        }
    }
    else
    {
        // Si pas de scriptaculous, on utilise Prototype
        if( mode == 0 )
        {
            $( id ).show();
        }
        else
        {
            $( id ).hide();
        }
    }
}
