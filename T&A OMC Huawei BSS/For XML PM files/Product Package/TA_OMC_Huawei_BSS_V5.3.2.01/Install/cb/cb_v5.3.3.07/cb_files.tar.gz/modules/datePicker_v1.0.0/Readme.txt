Module datePicker
--------------------------------------------------------------------

datePicker_v1.0.0
- correction bug 16753, remplace calendar pour compatibilite navigateur.
- Utilise JQueryui