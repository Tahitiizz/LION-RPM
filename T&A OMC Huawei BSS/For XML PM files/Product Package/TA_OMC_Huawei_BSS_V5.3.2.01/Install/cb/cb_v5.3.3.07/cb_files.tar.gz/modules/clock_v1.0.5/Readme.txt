Module clock
--------------------------------------------------------------------

clock_v1.0.5	-- SLC le 16/09/2008
- ajout du mode AM/PM

clock_v1.0.4	-- SLC le 10/09/2008
- le champ <input> est maintenant �ditable directement
- supression du champ cach� (pas n�cessaire, trop compliqu�)

clock_v1.0.3
- suppression de variables globales inutiles
- compatibilit� firefox (position + affichage des radio boutons)
- mise � jour du fichier exemple_2.html

clock_v1.0.2 
- image de l'horloge dans les css.
- un point virgule � chaque fin de ligne

clock_v1.0.1
- g�n�ration de div invisible � la place de balises map sur l'image.