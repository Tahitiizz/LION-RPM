<?php
/**
 * 
 * Classe repr�sentant les objets charg�s de d�terminer les conditions qui seront attribu�es � 
 * chaque processus. 
 * 
 * Chaque condition est "composite" (elle peut correspondre � plusieurs clauses where sql) : 
 * Cf. classe FileTypeConditionExp.class.php.
 * 
 * Chaque condition donnera lieu � une cr�ation de processus, c'est pourquoi indirectement,
 * la classe ConditionProvider d�termine le nombre de processus qui seront cr��s.  
 * 
 * Une condition permet � un processus de savoir quels fichiers sources
 * il doit traiter. Elle doit porter sur les tables sys_flat_file_uploaded_list et 
 * sys_definition_flat_file_lib. Elle est destin�e � �tre utilis�e dans la m�thode 
 * DatabaseServices.class.php->getFiles. 
 * 
 * Chaque parser (ex : ASN1, XML, CSV) peut disposer de sa propre classe sp�cifique h�ritant
 * de cette classe g�n�rique.
 *  
 * @package Parser library
 *
 */

class ConditionProvider {
	
	/**
	 * Condition principale associ�e � un parser donn� (par exemple flat_file_name= 'ASN1' pour un fichier le parser ASN1)
	 */
	public $parserCondition;
	

	
	/**
	 * Requ�tes SQL
	 */
	public $dbServices;
	
	
	/**
	 * 
	 * Nombre max de processus � cr�er par coeur de processeur
	 */
	protected $maxNumberOfProcessesPerCore;
	
	/**
	 * 
	 * Nombre min de processus � cr�er par coeur de processeur
	 */
	protected $minNumberOfProcessesPerCore;
	
	/**
	 * 
	 * Expression r�guli�re permettant de trouver un ID d'�l�ment r�seau
	 * au sein d'un nom de fichier source
	 */
	protected $templateForNE;
	
	/**
	 * 
	 * Entier repr�sentant la part des processus associ�e � ConditionProvider.
	 * Exemple 1 : 
	 * 			1 = 100% si un seul parser.
	 * Exemple 2 inspir� de Ericsson NSS : 
	 * 			0.3 pour le condition provider du parser XML
	 *   		0.7 pour le condition provider du parser ASN1
	 *   
	 *  La somme des poids des diff�rents ConditionProvider doit �tre �gale � 1.
	 */	
	protected $parserPoids;
	
	/**
	 * 
	 * Constructeur
	 * @param DatabaseServices $dbServices
	 */
	public function ConditionProvider (DatabaseServices $dbServices){
		$this->dbServices=$dbServices;
		
		//configuration par defaut
		$this->parserCondition=NULL;// cas NULL : Tous les fichiers sont trait�s par ce parser
		$this->maxNumberOfProcessesPerCore=4;
		$this->minNumberOfProcessesPerCore=2;
		$this->templateForNE=NULL;
		$this->parserPoids=1;
	}
	
	/**
	 * 
	 * Retourne la condition que doit v�rifier les fichiers trait� par ce 
	 */
	public function getParserCondition(){
		return $this->parserCondition;
	}
	/**
	 * 
	 * Retourne la liste des conditions qui seront attribu�es � chaque processus.
	 */
	public function getConditions(){
		// nombre processeurs consid�r�s comme disponible pour T&A
		// (le cas "plusieurs T&A" sur un m�me serveur)
		$numberOfProcessor=ProcessManager::getMaxNbOfSimultaneousProcess();
		
		// une condition par heure collect�e
		$hourArrayCondition=$this->getHoursConditions($this->parserCondition);
		
		// nb d'heures collect�es
		$nbOfHour=count($hourArrayCondition);

		// TODO JGU2 : g�n�rer un warning si $this->parserPoids est < 0 ou > 1.
		$minNumberOfProcesses=floor($this->minNumberOfProcessesPerCore*$numberOfProcessor*$this->parserPoids);
		$maxNumberOfProcesses=floor($this->maxNumberOfProcessesPerCore*$numberOfProcessor*$this->parserPoids);
		
		// si pas assez d�heure collect�es
		if($nbOfHour<=$minNumberOfProcesses){
			//on d�cline par heure d'abord
			$outputArrayCondition=$this->generateDeclinedConditions($this->parserCondition, $hourArrayCondition);
			$inputArrayCondition=$outputArrayCondition;
			
			// une condition par type de fichier associ� � ce parser
			$flatFileNameArrayCondition=$this->getFlatfileNamesConditions($this->parserCondition);
			
			// nb de ces types fichiers
			$nb_flat_file_names=count($flatFileNameArrayCondition);
			
			// si on a pas assez de  types de fichiers
			if(($nbOfHour*$nb_flat_file_names)<$minNumberOfProcesses){
				//on d�cline d'abord par flat_file_name
				$outputArrayCondition=array();
				foreach ($inputArrayCondition as $condition) {
					$outputArraytemp=$this->generateDeclinedConditions($condition,$flatFileNameArrayCondition);
					$outputArrayCondition=array_merge($outputArrayCondition,$outputArraytemp);
				}
				$inputArrayCondition=$outputArrayCondition;
				
				//si pas de d�coupage par NE possible
				if(!isset($this->templateForNE)) {
					displayIndemon(count($outputArrayCondition)." conditions ont �t� cr��es suite � une d�clinaison par heures ($nbOfHour) et par flat_file_names ($nb_flat_file_names) - pas de d�coupage par NE possible -.");
					return $outputArrayCondition;
				}
				//quels NE
				$neList=$this->dbServices->findNetElemCollected($this->templateForNE,$this->parserCondition);
				$numberOfNE=count($neList);
				$NEConditions=array();


				// si le nb d��l�ments nous convient
				if(($nbOfHour*$nb_flat_file_names*$numberOfNE)<$maxNumberOfProcesses){
					
					foreach ($neList as $neId) {
						$specifPattern=str_replace("(.+)", $neId, $this->templateForNE);
						$NEConditions[]=new FileTypeCondition("uploaded_flat_file_name","~*",$specifPattern);
					}
					
					$outputArrayCondition=array();
					foreach ($inputArrayCondition as $condition) {
						$outputArraytemp=$this->generateDeclinedConditions($condition,$NEConditions);
						$outputArrayCondition=array_merge($outputArrayCondition,$outputArraytemp);
					}
					displayIndemon(count($outputArrayCondition)." conditions ont �t� cr��es suite � une d�clinaison par heures ($nbOfHour), par flat_file_names ($nb_flat_file_names) et par el�ments r�seaux ($numberOfNE).");
					return $outputArrayCondition;

				}
				// si on a trop d��l�ments r�seaux
				else{
					//on cr�er des groupes de NE pour revenir au nombre max de process autoris�
					$nbOfNEGroup=floor($maxNumberOfProcesses/($nbOfHour*$nb_flat_file_names));			
					$numberOfNEPerGroup=floor($numberOfNE/$nbOfNEGroup);
					$numberOfNELeft=$numberOfNE%$nbOfNEGroup;
					
					$NEConditions=array();
					$counter=0;
					$NEConditionPerGroup=new FileTypeConditionExp();
					foreach ($neList as $neId) {
						$specifPattern=str_replace("(.+)", $neId, $this->templateForNE);
						$cCondition=new FileTypeCondition("uploaded_flat_file_name","~*",$specifPattern);
						$cCondition->operatorInterCondition="OR";
						$counter++;
						if($counter<=($numberOfNEPerGroup*$nbOfNEGroup)){
							if(($counter%$numberOfNEPerGroup)==0){
								$NEConditionPerGroup->add($cCondition);
								$NEConditions[]=$NEConditionPerGroup;
								$NEConditionPerGroup=new FileTypeConditionExp();
							}else{
								$NEConditionPerGroup->add($cCondition);
							}
						}else{
							$cConditionexp=$NEConditions[$counter-($numberOfNEPerGroup*$nbOfNEGroup)-1];
							$cConditionexp->add($cCondition);
						}

					}
					
					$outputArrayCondition=array();
					foreach ($inputArrayCondition as $condition) {
						$outputArraytemp=$this->generateDeclinedConditions($condition,$NEConditions);
						$outputArrayCondition=array_merge($outputArrayCondition,$outputArraytemp);
					}
					displayIndemon(count($outputArrayCondition)." conditions ont �t� cr��es suite � une d�clinaison par heures ($nbOfHour), par flat_file_names ($nb_flat_file_names) et par groupe d'�l�ments r�seaux ($nbOfNEGroup).");
					return $outputArrayCondition;
				}
			}
			// si le nb de types nous convient : on cr�e un process par couple � heure/type �
			elseif(($nbOfHour*$nb_flat_file_names)<=$maxNumberOfProcesses){
				//d�clin� par heure puis par flat_file_name
				
				$outputArrayCondition=array();
				foreach ($inputArrayCondition as $condition) {
					$outputArraytemp=$this->generateDeclinedConditions($condition,$flatFileNameArrayCondition);
					$outputArrayCondition=array_merge($outputArrayCondition,$outputArraytemp);
				}
				displayIndemon(count($outputArrayCondition)." conditions ont �t� cr��es suite � une d�clinaison par heures ($nbOfHour) et par flat_file_names ($nb_flat_file_names).");
				return $outputArrayCondition;
				
			}
			// si on a trop de types
			else{
				// on va cr�er autant de groupes de types que le nb de process max autoris� divis� par le nombre d'heure
				//car le nombre d'heure multiplie le nombre de process :
				//ex : 4heures, 7 groupes de flat_file_name => 28 process seront cr��s
				$nbOfFlatFileNamesGroup = floor($maxNumberOfProcesses/$nbOfHour);
				
				// nb minimum de types par groupe : en effet, certains groupes auront un type en plus, 
				// � moins que le nombre de types soit un multiple du nb de groupes de types.
				// floor : arrondit � l'entier inf�rieur.
				// exemple : si on a 11 types et un nb de process max �gal � 3 
				//        	 alors $minNumberOfFlatFileNamesPerGroup = 3
				//			 ce qui donnera la r�partition suivante :
				//					- process 1 : 4 types
				//					- process 2 : 4 types
				//					- process 3 : 3 types
				$minNumberOfFlatFileNamesPerGroup=floor($nb_flat_file_names/$nbOfFlatFileNamesGroup);

				// pour m�moriser les conditions correspondant � des groupes de types
				$flatFileGroupsConditions=array();
				
				// pour compter les types de fichiers � traiter
				$typesCounter=0;
				
				// 1er groupe de types � cr�er (ex : T5 OR T6 OR T7)
				$flatFileConditionsForCurrentGroup=new FileTypeConditionExp();
				
				// on parcourt les types 
				foreach ($flatFileNameArrayCondition as $cCondition) {
					
					// un "OU logique" plac� entre les types situ�s dans un m�me groupe de types 
					$cCondition->operatorInterCondition="OR";
					
					// nouveau tour de la boucle sur les types
					$typesCounter++;
					
					// si on peut continuer � dispatcher �quitablement les types dans les groupes de types
					if($typesCounter<=($minNumberOfFlatFileNamesPerGroup*$nbOfFlatFileNamesGroup)){						
						// "%" = modulo = reste de la division
						// si on le groupe de types courant contient d�sormais le nb de types attendu pour chaque groupe
						if(($typesCounter%$minNumberOfFlatFileNamesPerGroup)==0){
							// on ajoute le type courant au groupe de types courant, qui est d�sormais complet
							$flatFileConditionsForCurrentGroup->add($cCondition);
							// on m�morise le groupe de types ainsi compl�t�
							$flatFileGroupsConditions[]=$flatFileConditionsForCurrentGroup;
							// prochain groupe de type � cr�er
							$flatFileConditionsForCurrentGroup=new FileTypeConditionExp();
						}
						// sinon, on ajoute le type courant au groupe de types courant
						else{
							$flatFileConditionsForCurrentGroup->add($cCondition);
						}
					}
					// sinon, le type courant est l'un des quelques types restant � dispatcher
					else{
						// on s�lectionne un des groupes de types d�j� m�moris�s
						$cConditionexp=$flatFileGroupsConditions[$typesCounter-($minNumberOfFlatFileNamesPerGroup*$nbOfFlatFileNamesGroup)-1];
						// on ajoute le type courant � ce groupe
						$cConditionexp->add($cCondition);
					}
				}
				
				// r�sultat attendu : d�clinaisons par parser, hour et groupe de types 
				$outputArrayCondition=array();
				
				// $inputArrayCondition repr�sente les d�clinaisons par parser et hour
				// => on parcourt ces couples "parser/hour" :
				foreach ($inputArrayCondition as $condition) {
					// le couple "parser/hour" courant est d�clin� autant de fois qu'il y a de groupes de types
					$outputArraytemp=$this->generateDeclinedConditions($condition,$flatFileGroupsConditions);
					// on merge les r�sultats des diff�rents couples "parser/hour"
					$outputArrayCondition=array_merge($outputArrayCondition,$outputArraytemp);
				}
				displayIndemon(count($outputArrayCondition)." conditions ont �t� cr��es suite � une d�clinaison par heures ($nbOfHour) et par groupe de flat_file_names ($nbOfFlatFileNamesGroup).");
				return $outputArrayCondition;
			}
			
		// s�il suffit de cr�er un process par heure collect�e	
		}elseif ($nbOfHour<=$maxNumberOfProcesses){
			//on d�cline par heure
			$outputArrayCondition=$this->generateDeclinedConditions($this->parserCondition, $hourArrayCondition);
			
			displayIndemon(count($outputArrayCondition)." conditions ont �t� cr��es suite � une d�clinaison par heures ($nbOfHour)");
			return $outputArrayCondition;
		}
		// si on a trop d�heures donc chaque process va traiter un groupe d�heures
		else{
			// nb de groupes d'heures collect�es (= nb de processus � cr�er)
			$nbOfHoursGroup=$maxNumberOfProcesses;
			
			// nombre minimum d'heures par groupe d'heures
			$numberOfHoursPerGroup=floor($nbOfHour/$nbOfHoursGroup);	
			
			$NEConditions=array();
			$counter=0;
			$NEConditionPerGroup=new FileTypeConditionExp();
			
			// pour chaque heure collect�e
			foreach ($hourArrayCondition as $cCondition) {
				$cCondition->operatorInterCondition="OR";
				$counter++;
				if($counter<=($numberOfHoursPerGroup*$nbOfHoursGroup)){
					if(($counter%$numberOfHoursPerGroup)==0){
						$NEConditionPerGroup->add($cCondition);
						$NEConditions[]=$NEConditionPerGroup;
						$NEConditionPerGroup=new FileTypeConditionExp();
					}else{
						$NEConditionPerGroup->add($cCondition);
					}
				}else{
					$cConditionexp=$NEConditions[$counter-($numberOfHoursPerGroup*$nbOfHoursGroup)-1];
					$cConditionexp->add($cCondition);
				}
			}
			
			$outputArrayCondition=$this->generateDeclinedConditions($this->parserCondition,$NEConditions);
			
			displayIndemon(count($outputArrayCondition)." conditions ont �t� cr��es suite � une d�clinaison par groupe d'heures ($nbOfHoursGroup)");
			return $outputArrayCondition;
		}
		
		//END
	}
	
	
	
	
	
	
	/**
	 * 
	 * Retourne les conditions portant sur les types de fichiers et satisfaisant la 
	 * condition fournie en param�tre.
	 */
	protected function getFlatfileNamesConditions(FileTypeCondition $condition=NULL){
		$flat_file_names=$this->dbServices->getFlatfilenamesForCollectedFiles($condition);
		$conditionArray=array();
		foreach ($flat_file_names as $flat_file_name) {

			$flatFileNameCondition=new FileTypeCondition("flat_file_name", '=', $flat_file_name);
			$conditionArray[]=$flatFileNameCondition;
		}
		return $conditionArray;
	}
	
	/**
	 * 
	 * Renvoie un tableau de conditions (une condition pour chaque heure de fichier collect� 
	 * v�rifiant $condition)
	 * @param $condition
	 */
	protected function getHoursConditions(FileTypeCondition $condition=NULL){
		$hours=$this->dbServices->getHoursCollected($condition);
		$conditionArray=array();
		foreach (array_keys($hours) as $hour) {
			$hourCondition=new FileTypeCondition("hour", '=', $hour);
			$conditionArray[]=$hourCondition;
		}
		return $conditionArray;
		
	}
	
	/**
	 * 
	 * Ajoute $condition � chacune des conditions de $inputConditionsArray.
	 * @param unknown_type $condition
	 * @param unknown_type $inputConditionsArray
	 */
	protected function generateDeclinedConditions(FileTypeCondition $condition=NULL,$inputConditionsArray){
		//si condition=NULL
		if(!isset($condition)) return $inputConditionsArray;
		
		$conditionArray=array();
		foreach ($inputConditionsArray as $currentCondition) {
			$newCondition=new FileTypeConditionExp();
			$condition->operatorInterCondition="AND";
			$newCondition->add($condition);
			$newCondition->add($currentCondition);
			$conditionArray[]=$newCondition;
		}
		//si
		if(count($conditionArray)==0) return array($condition);
		return $conditionArray;
		
	}

	
}
?>