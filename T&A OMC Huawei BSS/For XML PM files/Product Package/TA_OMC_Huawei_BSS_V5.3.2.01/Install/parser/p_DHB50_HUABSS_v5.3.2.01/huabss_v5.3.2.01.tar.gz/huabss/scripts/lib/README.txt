V4.09
	- [Evolution] Modification de la m�thode getCountervalue pour g�rer les multivalued counters ayant des valeurs condens�es. Pas de modif c�t� sp�cifique concernant l'appelle � la m�thode.
	Il faut cependant modifier le code du parser s�pcifique pour g�rer l'attribution des valeurs pour les compteurs multi-valu�s condens�s
V4.08
	- [Evolution] Ajout de la famille Node-B dans le script d�activation des familles optionnelles. Pas de modif c�t� sp�cifique.
V4.07
	- [Evolution] Modification de la m�thode getCountervalue pour g�rer les multivalued counters. Pas de modif c�t� sp�cifique concernant l'appelle � la m�thode.
	Il faut cependant modifier le code du parser s�pcifique pour g�rer l'attribution des valeurs pour les compteurs multi-valu�s
V4.06
	- [Correction] Bug 37531 - [REC][ERICSSON][LTE] There is no message displayed when using optional_statistic script with option -l
V4.05
	- [Correction] Possibilit� de red�finir des m�thodes de la classe ExecQueryCopy cot� sp�cifique. Pas de modif c�t� sp�cifique.
V4.04
	- [Correction] Changement de la propri�t� hour � 5 dans "Data History" pour les familles optionelles. 
V4.03
	- [Correction] Modificaition de la m�thode OpenCsvHandles dans la class LoadTopology, afin que les fichiers temporaires soit bien supprim�s (suppression des fichier en .topo au lieu de .csv) Aucune modification c�t� sp�cifique
	- [Evolution] Ajout de la m�thode checkFileType dans la classe LoadData pour v�rifier si on collecte un fichier de topology et �viter la reprise de donn�e pour l'heure 00h00. Aucune modification c�t� sp�cifique
	- [Evolution] Modification de la m�thode waitEndOfAllProcess dans la classe ProcessManager pour eviter la r�p�tition du message 'parsing ongoing 100%' dans le process log. Aucune modification c�t� sp�cifique
	
V4.02
	- [Correction] le nms_table dans le todo est d�sormais insensible � la casse. Pas de modif c�t� sp�cifique.
	- [Correction] le scripts optional_statistics prends maintenant en compte la famille rnc. Pas de modif c�t� sp�cifique.
V4.01
	- [Correction] Gestion du mode multi process avec fichier de topologie. La signature du constructeur du parser sp�cifique a chang�. Modification requise c�t� sp�cifique.
	- [Correction] Historique horaire des statistiques optionnelles
	
V4.00
	- [Evolution] L'�volution majeure est la parall�lisation du step ExecCopyQuery. Pas de modif c�t� sp�cifique.
	- [Evolution] Suppression de la CTU. On fait maintenant l'upload de topology � chaque retrieve en traitant toutes les heures de la derni�re collecte. Pas de modif c�t� sp�cifique.
	- [Evolution] L'automatic mapping est fait une fois par jour, un nouveau param�tre global "automapping_last_update_date" est � ajouter dans le contexte. G�n�ration d'une erreur si absent. Pas de modif c�t� sp�cifique.
	- [Evolution] On n'utilise plus les param�tres "topology_last_update_date" et "topology_max_hour_retrieved". Peuvent �tre supprim�s du contexte. Pas de modif c�t� sp�cifique.
	- [Evolution] Ajout d'une m�thode Tools::getEntitiesForFlatFileName permettant de r�cup�rer plusieurs nms_table pour un m�me flat_file_name, ex : BSS & BSS GPRS - xxxx - RBS_PS_PCU_BTS|PACKET_CONTROL_UNIT. Pas de modif c�t� sp�cifique.
	- [Evolution] Ajout du script optional_statistics.php pour la gestion des statistiques optionnelles. Voir wiki. Penser � ajouter les param�tre globaux suivants : NSSX ("extended_topology"), BSS et UTRAN ("specif_enable_adjacencies","specif_enable_trx","specif_enable_iurlink","specif_enable_iublink","specif_enable_lac","specif_enable_rac") selon les familles pr�sentes. D�sactiver ces param�tres par d�faut dans le contexte. Le c�t� sp�cifique doit prendre en charge la gestion du parsing optionnel des familles.
	- [Correction] Mise � jour du script CreateTempTableCB.class.php pour tenir compte des corrections des CB 5.1.6.42 et 5.2.0.34. Pas de modif c�t� sp�cifique.
V3.08
	-[Correction] Retrait des caract�res accentu�s pour �criture dans le demon. Pas de modif c�t� sp�cifique.
	-[Evolution] Modification de la clause "order by" de la m�thode "CreateTempTable->getConditions" pour trier par famille puis par heure. Pas de modif c�t� sp�cifique.
	-[Correction] Suppression de l'affichage des statistiques de dur�es en mode "Single process". Pas de modif c�t� sp�cifique.
V3.07
	-[Correction] Suppression des espaces et caract�res se trouvant apr�s le tag fermant des scripts php. Sinon affichage inattendu dans le file demon. Pas de modifs c�t� sp�cifique. Penser � v�rifier les scripts sp�cifiques.
	-[Correction] BZ 30782 dans ConditionProvider, dans le cas de regroupement de conditions par heures et par groupe de flat_file_name, le nombre de groupe �tait mal calcul� pour maximiser le nombre de processus cr��s. Pas de modif c�t� sp�cifique.
V3.06

	-[Correction] lecture/ecriture du fichier paramsSerialized.ser: verrou exclusif en mode ecriture; verrou partag� en mode lecture.
V3.05
	-[Correction] Ajout d'un uniqid plus discriminant lors de la cr�ation d'index sur les tables temporaires dans la fonction CreateTempTableCB::create_group_table_temp_table pour �viter les index portant le m�me nom en cas de parall�lisation des taches. Pas de modif c�t� sp�cifique requise.

V3.04
	-[Correction] On surcharge �galement la m�thode create_temp_table::copy_temp_table_to_object_table du cb pour �viter les doublons dans les tables temporaires de topo. Pas de modification c�t� sp�cifique.
	-[Correction] En mode croisi�re, l'upload de topology se fait maintenant sur l'heure la plus r�cente. Pas de modif c�t� sp�cifique.
	-[Correction] Dans CreateTempTable::process, on ne v�rifie plus que la classe create_temp_table du cb n'a pas �volu�e. V�rifier que la m�thode n'a pas chang�e � chaque nouvelle livraison de cb.
	-[Evolution] Parallelisation du create_temp_table par heure. Pas de modif c�t� sp�cifique.
V3.03
	-[Correction] BZ29750 correction de la m�thode update_dynamic_counter_list (automatic mapping) dans le cas du mutli_process. Ajout d'un lock table sur la table sys_field_reference_all pour �viter que plusieurs process ins�rent en m�lme temps de nouveaux compteurs. Pas de modif c�t� sp�cifique.
	-[Correction] Le param�tre "topology_last_update_date" est seulement mis � jour lors du mode full ($this->topologyHour=='ALL'). Pas de modif c�t� sp�cifique.
	-[Correction] Ajout de verrous sur les fonction c�t� sp�cifique qui ins�rent dans les tables edw_object%. Ceci afin d'�viter les acc�s simultan�s en mode multi process. On surcharge �galement la m�thode create_temp_table::updateObjectRef du cb. Pas de modification c�t� sp�cifique.
	-[Evolution] Dans CreateTempTable::process, on v�rifie que la classe create_temp_table du cb n'a pas �volu�e depuis le dernier cb. Si changement, on passe en mode mono process pour le CreateTempTable. Modification requise c�t� sp�cifique si la m�thode du cb a �volu�e.
	-[Correction] On surcharge �galement la m�thode create_temp_table::insert_into_sys_to_compute du cb pour �viter les doublons. Pas de modification c�t� sp�cifique.
	-[Evolution] Le constructeur de la classe Parser prend d�sormais comme param�tre le bool�en single_process_mode, modification requise c�t� constructeur du parser sp�cifique.
	-[Evolution] Le constructeur de la classe create_temp_table_omc prend d�sormais un deuxi�me argument =single_process_mode. Modification requise c�t� sp�cifique.
	
V3.02
	-[Correction] correction de l'upload de topologie en cas de mono processus. Pas de modif c�t� sp�cifique requise.
	-[Correction] correction des messages de logs durant le parsing. Pas de modif c�t� sp�cifique.
V3.01
	- [Evolution] La m�thode Parameters->addTopologyInfo() a chang� de signature.Modifications requises cot� sp�cifique
	- [Correction] Des bugs ont �galement �t� corrig�s par rapport � la derniere version
V3.00
	- [Evolution] L'�volution majeure est la parall�lisation des scripts load_data.php et create_temp_table.php
	- [Evolution] La m�thode Tools::getCopyFilePath a chang� de signature.Modifications requises cot� sp�cifique
	- [Evolution] Ajout param�tres globaux "retrieve_perf_logs_enabled" et "retrieve_single_process"
	- [Evolution] Le constructeur de la classe DatabaseServices a chang� (plus d'objet ParameterList). Modifications requises cot� sp�cifique
	- [Evolution] Le constructeur de la classe ParserImpl doit avoir la signature suivante ParserImpl(DatabaseConnexion,FileTypeCondition=NULL) et ne pas oublier l'appel � parent::__construct().modifications requises cot� sp�cifique
	- [Evolution] On peut desormais h�riter de la classe LoadData pour notamment red�finir les m�thodes getDatabaseServicesClassName(),onParsingStart() et onParsingEnd().
	- [Evolution] Ajouter le fichier IncludeAllSpecific.php pour inclure les fichiers d�finissant les classes sp�cifiques notamment (ParserImpl,Configuration, DatabaseServicesImpl, CreateTempTableImpl).modifications requises cot� sp�cifique
	- [Evolution] Il est �galement n�cessaire d'h�riter de la classe ContentProvider si l'on veut red�finir un de ses param�tres par d�faut notamment parserPoids et templateForNE.
	- [Evolution] Pour �viter que plusieurs processus �crivent sur en meme temps sur un m�me fichier temporaire il faudra v�rouiller le fichier juste avant l'�criture : flock(resource,LOCK_EX), fwrite(), flock(resource,LOCK_UN). Modifications requises cot� sp�cifique
	- [Evolution] Les scripts create_temp_table_omc.class.php et create_temp_table.php ont l�g�rement chang� ; s�inspirer de Ericsson BSS

V2.11
	-[Correction] modification de update_dynamic_counter_list pour la compatibilit� postgres 8 et 9, et la prise en charge des compteurs avec parenth�ses et + dans leur nom lors de l'automatic mapping. Pas de modif c�t� sp�cifique.
	-[Correction] BZ 24198 ajout de l'appel � tracelogErrors() dans LoadTopology::load_files_topo(). Pas de modif c�t� sp�cifique. 
V2.10
	-[Correction] la m�thode update_dynamic_counter_list est d�sormais compatible postgres 8 et 9, pas de modif c�t� sp�cifique.
V2.9
	-[Correction] BZ 28843 correction de la m�thode DatabaseServices::activateSourceFileByCounter. Il faut �chapper par un antislash les motif de regexpe du type \s, \w, \d,.... Modification requise c�t� sp�cifique.

V2.8
	- [Evolution] Gestion des compteurs identifi�s par une position.
	- [Evolution] Recherche des fichiers collect�s : un nouveau param�tre permet de ne r�cup�rer que les fichiers d'un parser donn� (optimisation dans le cas de parsers multiples). Ce param�tre est optionnel donc aucune modification c�t� sp�cifique n'est requise.
	- [Evolution] createCopyBody : nouveau param�tre optionnel "flag_traitement_topo" permettant d'optimiser les perfs (on ne pr�pare pas l'upload de topo si on sait qu'il n'aura pas lieu). Modification conseill�e.
	
V2.7
	-[Correction] correction de la fonction update_dynamic_counter_list : echappements des caract�res sp�ciaux, pas de modif c�t� sp�cifique
V2.6
	-[Correction] BZ 28481 - [REC][T&A OMC Ericsson BSS][5.1.1.00] w_astellia tables are not purged after first retrieve when initializing bsc list (Parser->processDbInitTasks())
V2.5
	-[Evolution] L'automatic mapping est desormais compatible avec les compteurs d�clin�s (cad avec '@@' dans le nms_field_name)
V2.4
	-[Evolution] L'automatic mapping ne se fait maintenant qu'une fois par jour (parametre global "topology_last_update_date" utilis�)
	-[Evolution] Le parametre "topo_update_label" est desormais g�r� par le parser library.Modif c�t� sp�cifique requise
	-[Evolution] Les �l�ments r�seaux desactiv�s en topo ne seront plus int�gr�s
V2.3
	-[Correction] BZ 28197 : la m�thode DatabaseServices->completeDuplicatedFiles est corrig�e pour la maj des collectes virtuelles avec des fichiers multi TZ, pas de modif c�t� sp�cifique
	-[Correction] BZ 28180 : la m�thode DatabaseServices->activateSourceFileByCounter d'activation/d�sactivation des fichiers sources suivant les compteurs activ�s est corrig�e. Il faut d�sormais passer en param�tre de cette m�thode deux chaine repr�sentant un motif de regexp qui seront plac�s avant et apr�s le nms_table. Modif c�t� sp�cifique requise.
	-[Correction] BZ 28182 : Correction de la m�thode Parser->addToCountersList, le pr�fix_counter est d�sormais mis en minuscule.
V2.2
	- [Evolution] ajout de la m�thode CreateLteArc pour les produits LTE. Aucune modification c�t� sp�cifique requise.
V2.1
	- [Correction] corrections des m�thodes li�es au multi-timezones (27889)
	- [Correction] correction de l'automatic mapping, le nms_table est desormais insensible � la casse (27903)
V2.0
	- [Evolution] preferez l'utilisation de la m�thode Parser->getCptsByNmsTable() � Parser->getCptsInFile() lorsque le nms_table est connu
	- [Evolution] la m�thode Parser->addToCountersList() prend desormais en argument le nms_table au lieu du todo. Modification cot� sp�cifique requise.
	- [Evolution] les constructeurs des classe filles et le fichier load_data.php doivent changer. Modification cot� sp�cifique requise.
	- [Evolution] Parser->getCounterValue(): Utilisez dans le tableau de valeur des cl�s en minucules. Modification cot� sp�cifique requise.
	- [Evolution] Plus d'extension dans le nom des fichiers temporaires; voir m�thode Tools->getCopyFilePath(). Modification cot� sp�cifique requise.
	- [Correction] correction (mineure) de la m�thode CreateTempTable->setJoinDynamic() 
V1.9
	- [Evolution] la m�thode CreateTempTable->setJoinDynamic() prend desormais comme argument un objet de type Parameter.modif cot� sp�cifique requise
	- [Evolution] la m�thode DatabaseServices->update_dynamic_counter_list() a �galement �t� maj en tenant compte du nms_table sp�cifique "unknown"
V1.8
	- [Evolution] la m�thode abstraite  Collect->getFiletime() ne prend plus en argument le nom du fichier source mais desormais un objet de type Flatfile.modif cot� sp�cifique requise

V1.7
	- [Correction] compatibilit� postgresql 9 : la m�thode DatabaseServices->update_dynamic_counter_list() a �t� corrig�

V1.6
	- [Evolution] gestion des valeurs par d�faut des compteurs, modification de GetCounterValue, GetAllCounters. Il faut maintenant utilis� les param�tres globaux default_value_from_sfr et default_value_from_sfr_non_numeric_value  pour g�rer les diff�rents cas. 
	- [Correction] Erreur dans createFileTopo si fichier vide pour la famille, corrig�.
	
V1.5
	- [Evolution] Supprimez du cot� sp�cifique: la m�thode ParserImpl->getTopoCellsArray() si elle existe, supprimez "topo" de $fileType dans load_data.php
	- [Evolution] la topologie est g�r�e de mani�re diff�rente; il faut desormais utiliser la m�thode Parameters->addTopologyInfo() pour ajouter un �l�ment en topologie: modif cot� sp�cifique requis
	- [Evolution] ajout de la gestion/parsing des fichiers de topologie (Exple NSN UTRAN):Aucune modif cot� sp�cifique
V1.4
	- [Correction] BZ 25434 : �chappement des '+' dans les noms de compteurs

V1.3
    - [Correction] Bug 25864 : ajout de IF EXISTS dans "drop table captured_cells", fichier DatabaseServices.class.php
    - [Evolution] ajout de la methode getDeactivatedNe dans DatabaseServices.  Retourne les elements reseau desactives en topo.
    - [Evolution] Les compteurs d�clin�s ne sont pas sensibles � la casse.  fichier lib/Parser.class.php
    - [Evolution] S'il y a 0 fichier a traiter, il ne faut pas generer de log -> Suppression des messages "0 files to parse over 0 Hour(s)()". fichier lib/LoadData.class.php

V1.2	
	- [Correction] Modification de la m�thode createWimArc pour rattach� le vendor � l'apbs et non plus l'apgw

V0.9
 - [Evolution] Creer un lien vers le parser librabry: Ajouter sur le repertoire parser/<module>/script un svn:externals avec comme valeur 'lib http://asttools/svn/TA/TOOLS/parser_library/TAG/V0.9/lib' (� ajuster selon la version)
 - [Correction]	Modification de la methode Collect->activateSourceFileByCounter: les types de fichiers non pr�sents dans sys_field_reference ne seront pas concern�s(exemple de l'ASN1).Modification cot� specifique requis.
 - [Evolution] 	Ajout de la methode DatabaseServices->displayDataTable pour afficher en mode debug les tables NA et TA
 - [Correction]	Bug sur l'automatic mapping li� au double '|' : suppression de la m�thode Parser->getAutomaticMapping, creation d'une nouvelle m�thode Parser->addToCountersList et correction de la m�thode DatabaseServices->update_dynamic_counter_list. Modification cot� specifique requis.(s'inspirer de huawei BSS)
 - [Correction] Changement de la m�thode Parser->getCptsInFile suites aux probl�mes de compteurs et/ou des nms_tables dupliqu�s:Modification cot� specifique requis. (s'inspirer de huawei BSS)
