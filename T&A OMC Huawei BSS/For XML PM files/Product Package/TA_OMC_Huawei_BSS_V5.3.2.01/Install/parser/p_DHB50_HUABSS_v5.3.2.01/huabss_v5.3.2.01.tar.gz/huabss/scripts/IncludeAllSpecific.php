<?php
//load_data
include_once(REP_PHYSIQUE_NIVEAU_0 . "parser/$module/scripts/ParserHuaBssXml.class.php");
include_once(REP_PHYSIQUE_NIVEAU_0 . "parser/$module/scripts/Configuration.class.php");
include_once(REP_PHYSIQUE_NIVEAU_0 . "parser/$module/scripts/DatabaseServicesHuaBss.class.php");
include_once(REP_PHYSIQUE_NIVEAU_0 . "parser/$module/scripts/LoadDataHuaBss.class.php");


////create_temp_table
include_once(REP_PHYSIQUE_NIVEAU_0 . "parser/$module/scripts/create_temp_table_omc.class.php");

?>