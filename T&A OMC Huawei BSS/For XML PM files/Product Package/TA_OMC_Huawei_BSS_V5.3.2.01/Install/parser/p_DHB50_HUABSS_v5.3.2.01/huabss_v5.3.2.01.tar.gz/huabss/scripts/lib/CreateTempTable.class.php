<?php

include_once(REP_PHYSIQUE_NIVEAU_0 . "class/create_temp_table_generic.class.php");

abstract class CreateTempTable extends CreateTempTableCB {
	/**
	 * 
	 * D�finition des propri�t�s des familles
	 * @var ParametersList
	 */
	protected $params;
	
	/**
	 * 
	 * Connexion � la base de donn�es
	 * @var DataBaseConnection
	 */
	protected $database;
	
	/**
	 * Constructeur.
	 * Le constructeur parent fait appel aux fonctions g�n�riques du Composant de Base.
	 */
	public function __construct($tempTableCondition,$single_process_mode=TRUE)
	{
		parent::__construct($tempTableCondition,$single_process_mode);		
	}

	
	/**
	 * 
	 * Fonction qui d�fini sous forme de tableau pour chaque group de table les jointures � affectuer entre les tables contenant les donn�es des fichiers sources d'une facon dynamqiue
	 * Pb on ne doit pas faire de jointure si on trouve qu'une table en entr�e
	 * @param $param objet de type Parameter associ� � une famille
	 * 
	 *  Exemple de Ericsson BSS :
	 *      - $this->jointure : cell,hour,day,week,month,capture_duration,capture_duration_expected,capture_duration_real
	 *      - $this->specific_fields : cell,hour,day,week,month
	 */
	protected function setJoinDynamic($param){
		$level=$param->network[0];
		
		// recherche des tables temporaires w_astellia (1 table par entit�)
		$query = "
		  SELECT hour,
		         count(*) AS nb
		    FROM sys_w_tables_list
		   WHERE group_table='$param->id_group_table'
		     AND network='$level'
		GROUP BY hour";
		$values = $this->database->getRow($query);
		
		if($values["nb"]==1)
		{
			// on ne fait pas de jointure s'il n'y a qu'une table en entr�e
			// devrait �tre g�r� par le CB...
			displayInDemon(__METHOD__." : une seule table en entree, jointure non necessaire.");
			$this->jointure[$level] = "";
		}else{
			// 2 tableaux (= param�trage de la jointure) que le CB va utiliser
			$this->jointure[$level] 		= "(".$param->specific_field.")";
			if(preg_match("/(.*),capture_duration,/", $param->specific_field,$match))
				$jointure=$match[1];
			$this->specific_fields[$level] 	= $jointure;
			
			// logs dans le file_demon
			displayInDemon(__METHOD__." : jointure puis specific_fields :");
			// ex : cell,hour,day,week,month,capture_duration,capture_duration_expected,capture_duration_real
			var_dump($this->jointure);
			
			// ex :  cell,hour,day,week,month
			var_dump($this->specific_fields);
		}
	}

    
	/**
	 * Fonction qui va ajouter le vendor dans les tables de topologie
	 * s'il n'y existe pas d�j�.
	 * Appell�e par ./class/create_temp_table_generic.class.php 
	 * @param int $day jour trait�
	 */
	public function MAJ_objectref_specific($day=""){
		//On teste si le vendor a �t� cr�� en topo
		$vendorName = get_sys_global_parameters('vendor_name');
		//on ins�re le vendor que s'il n'existe pas d�j� (insensible � la casse de l'eor_id du vendor) ajout where not exists sinon erreur en multi process
		$query_vendor_insert  = "BEGIN WORK;
								LOCK TABLE edw_object_ref IN EXCLUSIVE MODE;
								INSERT INTO edw_object_ref (eor_date, eor_blacklisted, eor_on_off, eor_obj_type, eor_id, eor_label, eor_id_codeq) SELECT TO_CHAR(NOW(), 'YYYYMMDD'), 0, 1, 'vendor', '$vendorName', '$vendorName', NULL
								WHERE NOT EXISTS (SELECT 1 FROM edw_object_ref WHERE eor_obj_type = 'vendor' AND eor_id ILIKE '$vendorName')
								RETURNING edw_object_ref.oid
								;";
		$this->execRequeteAvecErreur($query_vendor_insert);
		$res=$this->database->getNumRows();
		$this->execRequeteAvecErreur("COMMIT WORK;");
	
		if($res==0){
			displayInDemon(__METHOD__." :: vendor '$vendorName' deja present dans edw_object_ref");
		}	
		else{ 
			displayInDemon(__METHOD__." :: vendor '$vendorName' ajoute a edw_object_ref");
		}
		return $vendorName;
	}
	
	/**
	 * 
	 * Cr�ation des arcs entre vendor et pcu / bsc pour les produits BSS
	 * @param String $vendorName
	 */
	protected function createBssArc($vendorName){
		//AJOUT DES ARCS MANQUANTS
		foreach(array('bsc','pcu') as $na){
			$query_arcs = "BEGIN WORK;
			LOCK TABLE edw_object_arc_ref, edw_object_ref IN EXCLUSIVE MODE;
			INSERT INTO edw_object_arc_ref
				(select eor_id, '".$vendorName."', '$na|s|vendor'
				FROM edw_object_ref r
				LEFT OUTER JOIN edw_object_arc_ref a ON r.eor_id = a.eoar_id AND a.eoar_arc_type = '$na|s|vendor'
				WHERE r.eor_obj_type = '$na' AND eoar_id IS NULL)
			;COMMIT WORK;";
			$this->execRequeteAvecErreur($query_arcs);
		}
	}
	
	/**
	 * 
	 * Cr�ation des arcs entre vendor et apgwpour la famille APS
	 * @param String $vendorName
	 */
	protected function createWimArc($vendorName){
		//AJOUT DES ARCS MANQUANTS
		foreach(array('apbs') as $na){
			$query_arcs = "BEGIN WORK;
			LOCK TABLE edw_object_arc_ref, edw_object_ref IN EXCLUSIVE MODE;
			INSERT INTO edw_object_arc_ref
				(select eor_id, '".$vendorName."', '$na|s|vendor'
				FROM edw_object_ref r
				LEFT OUTER JOIN edw_object_arc_ref a ON r.eor_id = a.eoar_id AND a.eoar_arc_type = '$na|s|vendor'
				WHERE r.eor_obj_type = '$na' AND eoar_id IS NULL)
			;COMMIT WORK;";
			$this->execRequeteAvecErreur($query_arcs);
		}
	}
	
	/**
	 * 
	 * Cr�ation des arcs entre vendor / network et rnc pour la famille UTRAN
	 * @param String $vendorName
	 */
	protected function createUtranArc($vendorName){
		//AJOUT DES ARCS MANQUANTS
		foreach(array('rnc') as $na){
			$query_arcs	= "BEGIN WORK;
			LOCK TABLE edw_object_arc_ref, edw_object_ref IN EXCLUSIVE MODE;
			INSERT INTO edw_object_arc_ref 
				(select eor_id, '".$vendorName."', '$na|s|vendor' 
				FROM edw_object_ref r 
				LEFT OUTER JOIN edw_object_arc_ref a ON r.eor_id = a.eoar_id  AND a.eoar_arc_type = '$na|s|vendor'
				WHERE r.eor_obj_type = '$na' AND eoar_id IS NULL)
			;COMMIT WORK;";
			$this->execRequeteAvecErreur($query_arcs);
		}
	}
	
	/**
	*
	* Cr�ation des arcs entre vendor et apgwpour la famille LTE
	* @param String $vendorName
	*/
	protected function createLteArc($vendorName){
		//AJOUT DES ARCS MANQUANTS
		foreach(array('enodeb') as $na){
			$query_arcs = "BEGIN WORK;
			LOCK TABLE edw_object_arc_ref, edw_object_ref IN EXCLUSIVE MODE;
			INSERT INTO edw_object_arc_ref
						(select eor_id, '".$vendorName."', '$na|s|vendor'
						FROM edw_object_ref r
						LEFT OUTER JOIN edw_object_arc_ref a ON r.eor_id = a.eoar_id AND a.eoar_arc_type = '$na|s|vendor'
						WHERE r.eor_obj_type = '$na' AND eoar_id IS NULL)
			;COMMIT WORK;";
			$this->execRequeteAvecErreur($query_arcs);
		}
	}
	
	/**
	 * 
	 * UPDATE sur la topo pour que les sourcecell label des ADJ soient mis � jour
	 * � partir des cell label
	 * @param String $vendorName
	 */
	protected function createAdjArc(){
		//  LOCK TABLE : attend si n�cessaire que tout verrou conflictuel soit rel�ch�, 
		// sauf si NOWAIT est sp�cifi�.
		// Une fois obtenu, le verrou est conserv� jusqu'� la fin de la transaction en cours 
		// (il n'y a pas de commande UNLOCK TABLE : les verrous sont syst�matiquement 
		// rel�ch�s � la fin de la transaction.) 
		$query_label = "BEGIN WORK;
			LOCK TABLE edw_object_ref IN EXCLUSIVE MODE;
			update edw_object_ref dest
	       set eor_label=r2.eor_label
	       from edw_object_ref as r1 INNER JOIN edw_object_ref as r2 ON r1.eor_id=r2.eor_id
	       where dest.eor_obj_type='sourcecell'
	       and r2.eor_obj_type='cell'
	       and dest.eor_id=r2.eor_id
		;COMMIT WORK;";
	   	$this->execRequeteAvecErreur($query_label);
	}
	
	/**
	 * 
	 * Ex�cute les requ�tes SQL avec gestion des erreurs
	 * @param String $sql
	 */
	private function execRequeteAvecErreur($sql){
    	$res = $this->database->execute($sql);
		if(($lErreur = $this->database->getLastError())!=''){
			displayInDemon($lErreur.'<br>'.$sql.';<br>'."\n", 'alert');
			return false;
		}else{
			if(Tools::$debug)	displayInDemon($sql."<br>\n");
			return $res;
		}
    }
    
    /**
	 * Fonction qui renseigne les tableaux $this->jointure et $this->specific_fields
	 * qui seront utilis�s par le CB.
	 * Ces tableaux d�finissent les jointures n�cessaires pour la g�n�ration des tables w_edw
	 * � partir des tables w_astellia (= tables par entit�).
	 * 
	 * Exemple de Ericsson BSS :
	 *      - $this->jointure : cell,hour,day,week,month,capture_duration,capture_duration_expected,capture_duration_real
	 *      - $this->specific_fields : cell,hour,day,week,month
	 * @param int $group_table_param identifiant le groupe de tables, c'est � dire la famille.
	 */
	public function get_join($group_table_param) {
		// pour les group tables g�n�r�es � partir de plusieurs tables, on definit la jointure
		$param = $this->params->getWithGroupTable($group_table_param);
		$this->setJoinDynamic($param);
		if (Tools::$debug) {
			displayInDemon(__METHOD__ . " DEBUG : jointure[] puis specific_fields[]");
			var_dump($this->jointure);
			var_dump($this->specific_fields);
		}
	}
	
	
	/**
	 * 
	 * Lance le create_temp_table en mono ou multiprocessus
	 * @param String $className
	 */
    public static function execute($className) {
		
		// choix du mode : single ou multi processus
		//si le parametre n'est pas d�fini get_sys_global_parameters renvoie 1
    	$retrieve_single_process=get_sys_global_parameters('retrieve_single_process',0)==0?FALSE:TRUE;
		
    	// la m�thode "get_group_table_from_w_table_list" du CB est red�finie pour
    	// permettre la parall�lisation au sein du create_temp_table, c'est pourquoi nous devons 
    	// v�rifier qu'elle est inchang�e c�t� CB.

    	//TODO maj si changement CB
    	//revoir la m�thode de comparaison des class cb, pb car md5 change suivant chaque cb
    	//md5 du script "create_temp_table_generic.class.php" crypt� du cb 5.1.6.32
//     	$create_temp_table_generic_md5_ref="e7995a1c0430e6e3adea25d02f664c8d";
    	
//     	if(md5_file(REP_PHYSIQUE_NIVEAU_0."class/create_temp_table_generic.class.php")!=$create_temp_table_generic_md5_ref){
//     		$retrieve_single_process=true;
//     		displayInDemon("warning: 'create_temp_table_generic.class.php' script has changed since the last CB, switching to single process mode");
//     	}

    	// purge des tables temporaires de topo
    	CreateTempTableCB::initTempTopoTables();
    	
    	// si cas mono processus
    	if($retrieve_single_process){
    		$CreateTempTableClass = new ReflectionClass($className);
    		//TODO passer un bool�en pour le multi process sur nouvelle instance
    		$CreateTempTableImpl = $CreateTempTableClass->newInstance(NULL,TRUE);
    	}
    	// sinon (cas multi processus)
    	else{    		
    		// nous allons cr�er un processus enfant par condition, c'est � dire
    		// par table temporaire
    		$conditionsTab = CreateTempTable::getConditions();
    		if (count($conditionsTab) > 0) {
    			$processManager=ProcessManager::getInstance();
    			$cmd='php lib/CreateTempTableScript.php';
    			foreach ($conditionsTab as $tempTableCondition) {
    				 
    				// table temporaire � traiter
    				$env['condition']=$tempTableCondition;
    				 
    				// nom de la classe fille de CreateTempTable � consid�rer
    				$env['class_name']=$className;
    				 
    				// mode multiprocess
    				$env['single_process_mode']=FALSE;
    				 
    				// lancment (ou mise en file d'attente) du nouveau processus
    				$processManager->launchProcess($cmd, $env);
    			}

    			// param�tre $displayLog=FALSE car on ne souhaite pas afficher des logs r�guli�rement
    			$processManager->waitEndOfAllProcess(FALSE);

    			// *************************************************************
    			$day = substr($conditionsTab[0]->hour, 0, 8);
    			    			
    			//$createTempTable = new create_temp_table();
    			// => Call to undefined method create_temp_table::MAJ_objectref_specific

    			// classe sp�cifique � consid�rer 
    			$CreateTempTableClass = new ReflectionClass($className);
		
    			// Appel au constructeur de la classe sp�cifique � consid�rer.
    			// Ce n'est pas tr�s "�l�guant" mais le code CB fait beaucoup de chose dans le constructeur ...
    			// Etapes 1 et 2 : ne font rien car la table � sys_w_tables_list � a d�j� �t� consomm�e, d'o� le log � No Group table to manage �.
    			// Etapes 3 � 5 : le 2nd param�tre = $single_process_mode = TRUE pour que la 
    			// m�thode "updateObjectRef" lance ces �tapes (via un appel au code du CB).
    			$CreateTempTableImpl = $CreateTempTableClass->newInstance($tempTableCondition,TRUE);    			
    			// *************************************************************
    		}
    	}
    }
    
    
    
    /**
     * M�thode qui retourne les conditions correspondants aux tables temporaires � traiter,
     * trouv�e dans la table "sys_w_tables_list".
     */
    protected static function getConditions() {
    	global $database_connection;   	
    	$conditionsTab = array();
    	// "ORDER BY hour DESC" car le jour le plus r�cent est utilis� dans la m�thode "updateObjectRef"
    	$query = "SELECT distinct hour, group_table, network FROM sys_w_tables_list ORDER BY group_table,hour DESC";
    	$res = pg_query($database_connection, $query);
    	$nbRows = pg_num_rows($res);
    	if ($nbRows > 0) {
    		for ($i = 0;$i < $nbRows; $i++) {
    			$row = pg_fetch_array($res);
    			$hour = $row["hour"];
    			$networkMinLevel = $row["network"];
    			$id_group_table = $row["group_table"];
    			$condition = new TempTableCondition($hour, $networkMinLevel, $id_group_table);
    			$conditionsTab[] = $condition;
    		}
    	}
    	return $conditionsTab;
    }

}

?>