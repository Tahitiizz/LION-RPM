<?php
/**
 * Fichier qui permet un traitement specifique au parser � la fin du retrieve.
 * 
 * @package Parser Huawei BSS 5.0
 * @author St�phane Lesimple 
 * @version 5.00.00.04
 */

// vide.

?>