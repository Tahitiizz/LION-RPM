
<?php
/**
 * Corps de chacun des processus lanc�s dans le cadre du parall�lisme interne
 * au create_temp_table. 
 * 
 */

try{	
	// includes et constantes du CB (dont REP_PHYSIQUE_NIVEAU_0)
	include_once(dirname(__FILE__)."/../../../../php/environnement_liens.php");
	
	// recherche du nom du parser
	$module = strtolower(get_sys_global_parameters("module"));
	
	// include des fichiers n�cessaires
	
	// include des scripts CB 
	include_once(REP_PHYSIQUE_NIVEAU_0 . "php/edw_function_family.php");
	include_once(REP_PHYSIQUE_NIVEAU_0 . "php/database_connection.php");
	include_once(REP_PHYSIQUE_NIVEAU_0 . "php/deploy_and_compute_functions.php");
	include_once(REP_PHYSIQUE_NIVEAU_0 . "php/postgres_functions.php");
	include_once(REP_PHYSIQUE_NIVEAU_0 . "class/create_temp_table_generic.class.php");
		
	// includes de la librairie parser
	include_once(REP_PHYSIQUE_NIVEAU_0 . "parser/$module/scripts/lib/IncludeAll.php");
	
	// includes du code sp�cifique
	include_once(REP_PHYSIQUE_NIVEAU_0 . "parser/$module/scripts/IncludeAllSpecific.php");
	
	// num�ro du processus courant (pid = "Process ID")
	$pid=getmypid();
	if($pid==FALSE){
		$message="Error: impossible to get process ID (PID)";
		sys_log_ast("Critical", "Trending&Aggregation", __T("A_TRACELOG_MODULE_LABEL_COLLECT"), $message, "support_1", "");
		displayInDemon($message,'alert');
		exit(-1);
	}
	
	// on commence � mesurer le temps d'execution de ce process
	Tools::debugTimeExcStart("process $pid");
	
	// redirige la sortie (= les logs destin�s au file_demon) vers un buffer qui sera 
	// vid� ult�rieurement.
	// L'objectif est de ne pas m�langer les logs des diff�rents processus.
	$bufferingStarted = ob_start();
	if($bufferingStarted==FALSE) displayInDemon("warning: temporisation des logs non enclenchee (Cf. ob_start)");
	
	displayInDemon("<span style='color:green;'><b>========= Step create_temp_table: output for process $pid - BEGIN =========</b></span>");
	
	// stocke le flux d'entr�e dans une cha�ne
	$serializedVars= stream_get_contents(STDIN);
	
	// convertit la cha�ne en variable PHP
	$var=unserialize($serializedVars);
	if($var==FALSE){
		$message="Error: impossible to unserialize variable 'serializedVars' ";
		sys_log_ast("Critical", "Trending&Aggregation", __T("A_TRACELOG_MODULE_LABEL_COLLECT"), $message, "support_1", "");
		displayInDemon("$message => $serializedVars",'alert');
		// arr�te de bufferiser les logs et vide le buffer dans le file_demon
		ob_end_flush();
		exit(-1);
	}
	try {
		// niveau r�seaux minimum de la famille (ou des familles) � traiter pour le nouveau processus
		$tempTableCondition=$var['condition'];
		
		// nom de la classe sp�cifique � consid�rer (classe fille de lib/CreateTempTable,
		// le plus souvent : create_temp_table_omc)
		$className=$var["class_name"];
		
		//mode single_process pass� � false
		$single_process_mode=$var["single_process_mode"];
		
		// classe sp�cifique � consid�rer 
		$CreateTempTableClass = new ReflectionClass($className);
		
		// appel au constructeur de la classe sp�cifique � consid�rer
		$CreateTempTableImpl = $CreateTempTableClass->newInstance($tempTableCondition,$single_process_mode);
		
		// �tapes 1 et 2
		//$CreateTempTableImpl->stepOneAndTwo();
		
	}catch (ReflectionException $ex) {
		$message="Error: instantiation of CreateTempTable object failed (" . $ex->getMessage().")";
		sys_log_ast("Critical", "Trending&Aggregation", __T("A_TRACELOG_MODULE_LABEL_COLLECT"), $message, "support_1", "");
		displayInDemon($message,'alert');
		// arr�te de bufferiser les logs et vide le buffer dans le file_demon
		ob_end_flush();
		exit(-1);
	}
	
	// fin du chronom�trage
	$processDuration=Tools::debugTimeExcEnd("process $pid");
	displayInDemon("<span style='color:green;'><b>========= Step create_temp_table: output for process $pid - END =========</b></span>");
		
	// arr�te de bufferiser les logs et vide le buffer dans le file_demon
	ob_end_flush();
	
	// 0 = tout s'est bien pass�
	exit(0);


}//End of try
catch (Exception $ex) {
	$message="Error: captured error (" . $ex->getMessage().")";
	sys_log_ast("Critical", "Trending&Aggregation", __T("A_TRACELOG_MODULE_LABEL_COLLECT"), $message, "support_1", "");
	displayInDemon($message,'alert');
	// arr�te de bufferiser les logs et vide le buffer dans le file_demon
	ob_end_flush();
	exit(-1);
}

?>