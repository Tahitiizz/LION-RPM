<?php
/**
 * Fichier qui contient des fonctions g�n�riques utilis�es dans les classes propres � chaque type de fichier � traiter
 * 
 * @package Parser library
 *
 */

abstract class Parser {
	
	public $parserFileName;
	/**
	 * @var type de ficher � traiter
	 */
	protected  $fileType;
	/**
	 * 
	 * Liste des param�tres statiques d�finis pour chaque famille
	 * @var ParametersList
	 */
	protected $params;
	/**
	 * 
	 * Valeur du param�tre global du contexte produit
	 * @var String
	 */
	protected $default_value_from_sfr;
	/**
	 * 
	 * Valeur du param�tre global du contexte produit d�finissant la valeur par d�faut en cas de valeur non num�rique d'un compteur
	 * @var String
	 */
	private $default_value_from_sfr_non_numeric_value;
	/**
	 * 
	 * Permet l'acc�s aux fonctions de requ�te vers la base de donn�es
	 * @var DatabaseServices
	 */
	public $dbServices;
	
	/**
	 * 
	 * Structure de donn�es comptenant les compteurs pr�sents dans les fichiers sources pars�s (id_group_table, nms_table, counters list)
	 * @var array
	 */
	private $listOfCountersInSourceFiles;
	
	/**
	 * 
	 * Stockage de la valeur de query_ri
	 * @var String
	 */
	public static $query_ri;
	/**
	 * 
	 * Stockage de la valeur de aggreg_net_ri
	 * @var String
	 */
	public static $aggreg_net_ri;
	/**
	 * 
	 * Stockage de la valeur de time_coef
	 * @var String
	 */
	public static $time_coef;
	/**
	 * 
	 * Stockage de la valeur de capture_duration_expected
	 * @var String
	 */
	public static $capture_duration_expected;
	
	/**
	 * 
	 * Mono ou multi processus
	 * @var boolean
	 */
	protected $retrieve_single_process;
		
	public $processManager;


	/**
	 * 
	 * Constructeur
	 * @param $dbServices
	 * @param $parameterList
	 * @param $parserFileName
	 * @param $fileType
	 * @param $single_process_mode
	 */
	public function Parser(DatabaseServices $dbServices, ParametersList $parameterList,$parserFileName,FileTypeCondition $fileType=NULL,$single_process_mode=TRUE)
	{
		$this->dbServices=$dbServices;
		$this->params=$parameterList;
		$this->parserFileName=$parserFileName;
		$this->fileType = $fileType;
		$this->initiateParam();
		$global_parameters = edw_LoadParams();
		
// 		//mono ou multi processus: si le parametre n'est pas d�fini (NULL) ou est � 1 retrieve_single_process=TRUE. Sinon False
// 		if(isset($global_parameters['retrieve_single_process']) )
// 			$this->retrieve_single_process=$global_parameters['retrieve_single_process']==1?TRUE:FALSE;
// 		else $this->retrieve_single_process=false;
		
		//mono ou multi processus: si le parametre n'est pas d�fini (NULL) ou est � 1 retrieve_single_process=TRUE. Sinon False
		$this->retrieve_single_process=$single_process_mode;
		
		Parser::$capture_duration_expected = $global_parameters["capture_duration"];
		// Si la valeur n'existe pas dans le contexte, la valeur par d�faut pour ce param�tre est 1
		$this->default_value_from_sfr = ($global_parameters["default_value_from_sfr"] == null) ? 1 : $global_parameters["default_value_from_sfr"];
		//valeur � 0 par d�faut (ex : si le param�tre n'existe pas), i.e. "NULL when value is non numeric"
		$this->default_value_from_sfr_non_numeric_value = 0;
		if(isset($global_parameters["default_value_from_sfr_non_numeric_value"])) {
			$default_value_from_sfr_non_numeric_value = $global_parameters["default_value_from_sfr_non_numeric_value"];
			if($default_value_from_sfr_non_numeric_value == 0 || $default_value_from_sfr_non_numeric_value == 1) {
				$this->default_value_from_sfr_non_numeric_value = $default_value_from_sfr_non_numeric_value;
			}
		}
		$this->listOfCountersInSourceFiles = array();
		$this->processManager=ProcessManager::getInstance();
	}
	

	/**
	 * 
	 * Renvoie la liste des heures o� des fichiers ont �t� collect�s
	 */
	public function getHoursCollected() {
		$hours = $this->dbServices->getHoursCollected($this->fileType);
		return $hours;
	}
	

	
	/**
	 * 
	 * R�cup�re la valeur ou valeur par d�faut du compteur $counterName
	 * @param Counter $counter Objet Counter qui d�finit le compteur
	 * @param array $data Liste des valeurs des compteurs
	 * @param bool $globalCounter permet de savoir si le compteur est un compteur explicit false par d�faut
	 * @param bool $explicit permet de savoir si le compteur a des valeurs explicite false par d�faut
	 * @return String $value la valeur du compteur $counterName
	 */
	protected function getCounterValue(Counter $counter, $data, $globalCounter = false,$explicit = false) {
		$val = null;
        // cas des compteurs d�clin�s 
        // ex : nms_field_name vaut NUMDEST_ANSWERED_CALLS@@DEST_DIR_ID=1&&DEST_TYPE_ID=10
        // dans ce cas on prend la valeur de NUMDEST_ANSWERED_CALLS si DEST_DIR_ID=1 ET DEST_TYPE_ID=10
        if (strpos($counter->nms_field_name[0],"@@")){
            $array_declined = explode("@@",strtolower($counter->nms_field_name[0]));
            if (isset($data[$array_declined[0]])) {
                $values_declined = explode("&&",$array_declined[1]);
                $stop=0;
                while($stop==0){
                    foreach ($values_declined as $elt){
                        $tab=explode("=",$elt);
                        if($data[$tab[0]]!=$tab[1])
                            $stop=1;
                    }
                    break;
                }
                if ($stop==0)
                    $val = $data[$array_declined[0]];
            }
        }
        // compteurs non d�clin�s
        foreach ($counter->nms_field_name as $nms_field_name) {     	
        	if(isset($data[$nms_field_name])){
        		$rawVal = $data[$nms_field_name];
        		//Cas d'un Multivalued counter
        		if($counter->flat_file_position !== null && $counter->flat_file_position != ''){
					if($counter->flat_file_position >=0){
						if($explicit == true){
							$position = intval($counter->flat_file_position);
							$arrayValue = explode(",", $rawVal);
							//on r�cup�re la valeur du compteur � la bonne position dans le tableau
							$val = $arrayValue[$position];
						}else{
							$position = intval($counter->flat_file_position);
							$rawVal = substr($rawVal,2,strlen($rawVal));
							$arrayValue = explode(',', $rawVal);
							$valPreSum = array();
							$indexPreSum = array();
							foreach ($arrayValue as $key=>$value) {
									if($key % 2 == 1){
										array_push($valPreSum,$arrayValue[$key]);
									}else{
										array_push($indexPreSum,$arrayValue[$key]-1);
									}  
							}
							// comme les index trouv�s dans les valeur condens�es commence � 1 on utilisera position +1 
							if(in_array($position,$indexPreSum)){
								$key = array_search($position, $indexPreSum);
								$val = $valPreSum[$key];
							}else{
								$val = '0';
							}
						}
					}else{
						if($globalCounter === true){
							//cas d'un global counter condens� : on saute la 1�re valeur et on fait la somme d un nombre sur 2 
							//ex: <r>2,2,15,6,25</r> ici le total sera �gale � 15+25 = 40
							if($counter->flat_file_position == -2){
			        			if($rawVal =="0" || $rawVal ==""){
			        				$val = '0';
			        			}else{
			        				$rawVal = substr($rawVal,2,strlen($rawVal));
				        			$arrayValue = explode(',', $rawVal);
				        			$valPreSum = array();
									foreach ($arrayValue as $key=>$value) {
										if($key % 2 == 1){
											array_push($valPreSum,$arrayValue[$key]);
										}   
									}
									$val = array_sum($valPreSum);
			        			}  	
				        	}
				        	//cas d'un global counter explicte on fait un summ de toute les valeurs
				        	else if($counter->flat_file_position == -1){
				        		$arrayValue = explode(",", $rawVal);
								$val = array_sum($arrayValue);
			        		}
						}
					}
				}else{
						$val = $data[$nms_field_name];
				}
				if(!(is_numeric($val))){
					if (preg_match('/^([0-9]+),(([0-9]+))$/', $val))
						$val = floatval(str_replace(',', '.', $val));
					else
						return ($this->default_value_from_sfr_non_numeric_value == 0 ? "" : $counter->default_value);
				}
				
        	}	
        }
       
        return ($val === null && $this->default_value_from_sfr == 1 ? $counter->default_value : $val);
        
    }


	/**
	 * 
	 * Renvoie la liste des types des champs SQL des compteurs
	 * @param array $header Tableau contenant les �l�ments de l'en-t�te du fichier source

	 */
    /**
     * 
     * Enter description here ...
     * @param $header tableau de la liste des compteurs � chercher
     * @param $id_group_table (optionnel) � renseigner si connu plour am�liorer les performances
     * @return array Tableau des objets Counter pr�sents, par todo, dans le fichier source
     */
	protected function getCptsInFile($header,$id_group_table=null) {
		$edw_ordered_list = array();
		foreach ($header as $value) {
			if (strncmp($value, "capture_duration", 16) === 0) { continue; }
			$counters = $this->params->getCounterFromFile($value,$id_group_table);	
			// On ne garde que les compteurs actifs		
			/*if (isset($counter) && $counter[1]->on_off == 1) {
				$edw_ordered_list[$counter[0]] = $counter[1];
			}*/
			if (isset($counters)) {
				foreach ($counters as $counter) {
					if (isset($counters)) {
						foreach ($counters as $counter) {
							if($counter->on_off == 1){
								$todo=Tools::getTodoString($counter->family, $counter->nms_table);
								$edw_ordered_list[$todo][] = $counter;
							}
							
						}
					}
					
				}
			}
		}
		return $edw_ordered_list;
	}
	
	protected function getCptsByNmsTable($nms_table){
		return $this->params->getCountersByNmsTable($nms_table);
	}

	
	/**
	 * 
	 * Purge de la table sys_flat_file_uploaded_list pour l'heure $hour
	 * @param String $hour Heure des fichiers collect�s
	 */
	public function cleanFlatFileUploadedList() {
		$this->dbServices->clean_flat_file_uploaded_list($this->collectedFlatfiles);
	}

	/**
	 * 
	 * Ajouter les compteurs trouv�s dans le fichiers sources dans une structure de donn�es
	 * @param array $counters_in_source_file
	 * @param string $nms_table
	 * @param int $id_group_table
	 * @param string $prefix_counter
	 */
	public function addToCountersList($counters_in_source_file, $nms_table, $id_group_table, $prefix_counter = null){
		//on r�cup�re le nms_table � partir du todo
		//nms_table insensible � la casse
		$nms_table=strtolower($nms_table);
		foreach ($counters_in_source_file as $counter){
			//construction de la structure de donn�e
			if(! isset($this->listOfCountersInSourceFiles[$id_group_table])) $this->listOfCountersInSourceFiles[$id_group_table] = array();
			if(! isset($this->listOfCountersInSourceFiles[$id_group_table][$nms_table])) $this->listOfCountersInSourceFiles[$id_group_table][$nms_table] = array();
			$this->listOfCountersInSourceFiles[$id_group_table][$nms_table][$counter]=strtolower($prefix_counter);
		}
	}
	
	/**
	 * M�thode appell�e � la fin du retreive 
	 * Regarde s'il y a des nouveaux compteurs et proc�de � l'insertion de ceux-ci dans sys_field_reference_all (en se basant sur $listOfCountersInSourceFiles)
	 * 
	 */
	public function addDynamicCountersToSysFieldReferenceAll(){
		$this->dbServices->update_dynamic_counter_list($this->listOfCountersInSourceFiles);
	}
	
	/**
	 * 
	 * Parse le fichier source fourni en param�tre et cr�e un fichier CSV destin� � la 
	 * commande SQL "COPY" (cr�ation des tables temporaires)
	 * @param FlatFile $flat_file Fichier collect�
	 * @param booleen $topologyHour Heure sur laquelle doit se baser l'upload de 
	 * topo (mode croisi�re de la CTU). ALL = toutes les heures (mode full de la CTU).
	 */
	abstract protected function createCopyBody(FlatFile $flat_file, $topologyHour='ALL');
		

	
	
	/**
	 * 
	 * Retourne la propri�t� $this->params
	 * @return array Liste d'objets Parameters
	 */
	public function getParams() {
		return $this->params;
	}
	
	
	/**
	 * 
	 * Renvoie un tableau contenant, par familles, les info de topologie
	 */
	public function getTopoCellsArray() {
		$topoCellsArray = array();
		foreach ($this->params as $param) {
			if (isset($param->topoCellsArray) && is_array($param->topoCellsArray)) {
				$topoCellsArray[$param->family] = $param->topoCellsArray;
			}
			else {
				$topoCellsArray[$param->family] = array();
			}
		}
		return $topoCellsArray;
	}
	/**
	 * 
	 * Cette m�thode est ex�cut�e � la fin du parsing des fichiers v�rifiant la condition.
	 * Elle est est disponible pour d�velopper si besoin des actions c�t� sp�cifique.
	 */
	protected function endOfParsingPerCondition(){
		//empty
	}

	
	/**
	 * 
	 * Lance les traitements principaux du process Retrieve
	 * $topologyHour : heure pour laquelle l'upload de topo doit avoir lieu (ou "ALL" 
	 * si la CTU est en mode "full").
	 */
	public function process($topologyHour) {

		//existe-t-il des fichiers de ce type de parser et la condition "$this->fileType"
		$this->collectedFlatfiles = $this->dbServices->getFiles($this->fileType);
		
		if(!$this->collectedFlatfiles->valid()) {echo "No file for condition {$this->fileType->getDBCondition()}" ;return;}			

		// d�but du traitement des fichiers collect�s s�lectionn�s via la condition "$this->fileType"
		foreach ($this->collectedFlatfiles as $flatFile) {
			// flat_file_name : nom du type de fichier (ex : ASN1 pour Ericsson BSS)
			// uploaded_flat_file_name : nom du fichier source pr�c�d� d'un ID de la connexion 
			// (ex : local_home_mde_eribss_ref_flat_file_20111024.1800_C20111024.1800-20111024.1900_CUDRBS1:1000)
			displayInDemon('********** groupe de fichiers '.$flatFile->flat_file_name.' : '.$flatFile->uploaded_flat_file_name.' ************');
			
			// parsing du fichier source et cr�ation d'un fichier CSV destin� � la 
	 		// commande SQL "COPY" (cr�ation des tables temporaires)
			if (Tools::isPerfTraceEnabled()) {Tools::debugTimeExcStart("createCopyBody");}
			// m�thode sp�cifique � chaque parser
			$this->createCopyBody($flatFile, $topologyHour);
			if (Tools::isPerfTraceEnabled()) {Tools::debugTimeExcEnd("createCopyBody");}
		}
		
		//fin de parsing des fichiers v�rifiants la condition
		$this->endOfParsingPerCondition();

		//supprime les fichiers de l'heure courante.
		$this->cleanFlatFileUploadedList();

		// date du dernier automatic mapping 
		$automapping_last_update_date = get_sys_global_parameters("automapping_last_update_date");
		
		//automatic mapping only once a day
		if($automapping_last_update_date != date("Ymd") || $automapping_last_update_date==0){
			// MAJ du param�tre global 'automapping_last_update_date' : la m�thode updateLastAutomappingDate() 
			// est appel�e dans le LoadData � la fin du parsing.
			$this->addDynamicCountersToSysFieldReferenceAll();
		}
		
		//serialisation de la topologie
		$topologyArray=$this->getTopoCellsArray();
		$serialisedTopo=serialize($topologyArray);		
		$filename=REP_PHYSIQUE_NIVEAU_0 . "parser/topoSerialized.ser";
		// option "a+" : Open for reading and writing; place the file pointer at the end of the file. If the file does not exist, attempt to create it.
		$fileHandle=fopen($filename,'a+');
		if($fileHandle!=false){
			
			// Verrouillage du fichier par le processus, bloque l'�criture jusqu'� lib�ration 
			// du fichier par un autre processus.
			// => doit fonctionner puisque nos processus enfants sont des processus "lourds", et donc
			// vus comme des processus diff�rents par le syst�me.
			// LOCK_EX : met en place un verrou exclusif (�criture) => the CALL WILL BLOCK UNTIL ALL OTHER LOCKS have been released.
			flock($fileHandle, LOCK_EX);
			fwrite($fileHandle, $serialisedTopo);
			fwrite($fileHandle, "\nEND_ARRAY\n"); // END_ARRAY : marqueur de fin d'objet serialis�
			// LOCK_UN : lib�rer le verrou (qu'il soit partag� ou exclusif)
			flock($fileHandle, LOCK_UN);
			fclose($fileHandle);		
		}else{
			$message="ERROR: topologie not saved for this process. file ($filename)";
			sys_log_ast("Critical", "Trending&Aggregation", __T("A_TRACELOG_MODULE_LABEL_COLLECT"), $message, "support_1", "");
			displayInDemon($message,'alert');
		}
	}
	
	/**
	 * 
	 * Initialise des propri�t�s d'objet ParameterList
	 * @param array $family2Param Tableau associatif pour les param�tres field, specific_field, group_table et network
	 * 
	 */
	protected function initiateParam() {

		$filename=REP_PHYSIQUE_NIVEAU_0 . "parser/paramsSerialized.ser";
		// si aucun processus n'a eu le temps de finir de cr�er ce fichier
		// (plusieurs processus peuvent rentrer dans ce "if" : les "file_put_contents"
		// ci-dessous vont alors s'�craser les uns les autres)
		if(!file_exists($filename)){

			//ON PREPARE LA LISTE DES FICHIERS A TRAITER
			// on liste les compteurs *** activ�s ***
			$counters = $this->dbServices->getAllCounters($this->params);
			
			// on liste les todo � traiter
			$tabTodo = array();
			foreach($counters as $counter) {
				$tabTodo[] = Tools::getTodoString($counter->family, $counter->nms_table);
			}
			// on d�doublonne $tabTodo
			$tabTodo = array_unique($tabTodo);
			
			// On initialise la liste des todo de la structure $this->params
			// Chaque $this->params->todo contient la liste de tous les objets Counter actifs d�finis dans la table sys_field_reference
			foreach($tabTodo as $todo) {
				if (preg_match("/^([[:alnum:]]+)_/", $todo, $regs) ) {
					$family = $regs[1];
					$nmsTable = substr($todo, strpos($todo, '_') + 1);
					$todoCounters = $counters->getWithTodo($todo);
					$param = $this->params->getWithFamily($family);
					$param->todo[$todo] = $todoCounters;
				}
				else {
					displayInDemon(__METHOD__ . " ERROR, $todo n'est pas de la forme attendue", "alert");
				}
			}
			// renseigne les listes d'�l�ments r�seaux desactiv�
			// (les $param->deactivated_NE)
			$this->dbServices->deactivatedNEPerFamily($this->params);
			
			//serialisation et sauvegarde
			$paramsSerialized=serialize($this->params);
			
			// stockage du param�trage dans un fichier avec verrou Exclusif.
			// 		file_put_contents : If filename does not exist, the file is created. Otherwise, the existing file is overwritten, unless the FILE_APPEND flag is set.
			//      LOCK_EX means (EXCLUSIVE LOCK) : only a single process may possess an exclusive lock to a given file at a time. 
			$paramsAreStored=file_put_contents($filename,$paramsSerialized,LOCK_EX);
			if($paramsAreStored==false) {
				$message="Error: Unable to create parameter file ($filename)";
				sys_log_ast("Critical", "Trending&Aggregation", __T("A_TRACELOG_MODULE_LABEL_COLLECT"), $message, "support_1", "");
				displayInDemon($message,'alert');
			}
			
		}
		// Sinon, le fichier existe et on l'utilise (gain en perf!).
		// Il est complet (= non corrompu) car l'op�ration
		// de cr�ation de ce fichier est atomique (voir "file_put_contents" ci-dessus). 
		else{
			$paramsSerialized="";
			$handle=fopen($filename,'rt');
			if ($handle) {
				//verrou en lecture partag�e (bloque jusqu'� lib�ration du verrou exlusif s'il existe)
				flock($handle, LOCK_SH);
			    while (!feof($handle)) {
			        $paramsSerialized .= fgets($handle);
			    }
			    flock($handle, LOCK_UN);//d�v�rouillage
			    fclose($handle);
			}else{
				$message="Error: Unable to open parameter file ($filename)";
				sys_log_ast("Critical", "Trending&Aggregation", __T("A_TRACELOG_MODULE_LABEL_COLLECT"), $message, "support_1", "");
				displayInDemon($message,'alert');
			}			
			$this->params=unserialize($paramsSerialized);
			if(($this->params==false)||($this->params=='')){
				$message="Error: Unable to unserialize parameter file ($filename)";
				sys_log_ast("Critical", "Trending&Aggregation", __T("A_TRACELOG_MODULE_LABEL_COLLECT"), $message, "support_1", "");
				displayInDemon($message,'alert');
			}
		}

	}
	
	

	/**
	 * 
	 * Retourne le ConditionProvider � utiliser pour ce parser.
	 * A red�finir c�t� sp�cifique si besoin.
	 * @param unknown_type $dbServices
	 */
	public static function getConditionProvider($dbServices){
		return new ConditionProvider($dbServices);
	}
	


}
?>